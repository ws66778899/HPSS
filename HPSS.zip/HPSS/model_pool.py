# model_pool.py
import torch.nn as nn
import torch
from model.encoder5 import SpatialEncoder1   # 按实际路径导入
from model.encoder5 import SpectralEncoder1

# 全局单例
_spat_enc = SpatialEncoder1(input_channels=100, patch_size=9, feature_dim=128)
_spec_enc = SpectralEncoder1(input_channels=100, patch_size=9, feature_dim=128)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
_spat_enc = _spat_enc.to(device).eval()
_spec_enc = _spec_enc.to(device).eval()

def get_encoders():
    return _spat_enc, _spec_enc