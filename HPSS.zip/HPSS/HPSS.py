import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
from torch.utils.tensorboard import SummaryWriter
from torch.optim.lr_scheduler import StepLR
from torch.utils.data import DataLoader, Dataset
from torch.utils.data.sampler import Sampler
import numpy as np
import os
import math
import argparse
import scipy as sp
import scipy.stats
import pickle
import random
import scipy.io as sio
from sklearn.decomposition import PCA
from sklearn import metrics
import matplotlib.pyplot as plt
from scipy.io import loadmat
from sklearn import preprocessing
from sklearn.neighbors import KNeighborsClassifier
from matplotlib import pyplot
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
import time
import utils
import copy
import logging
import imp
from model.BBB import DPGN
from model import AAA as CSA_block  # 从 model 文件夹导入 AAA 模块（原名 CSA_block修改后），别名保持 CSA_block
from model.CCC import Encoder
import warnings
import data_augment
from datetime import datetime


import sys

# 定义一个同时输出到控制台和文件的类（核心逻辑，无需修改）
class ConsoleAndFileOutput:
    def __init__(self, file_path):
        self.console = sys.stdout  # 保存原控制台输出
        self.file = open(file_path, 'w', encoding='utf-8')  # 打开TXT文件，w=覆盖，a=追加

    def write(self, msg):
        # 同时写入控制台和文件"""
        self.console.write(msg)
        self.file.write(msg)
        self.file.flush()  # 立即写入，避免内容缓存

    def flush(self):
        # 兼容系统要求的flush方法
        self.console.flush()
        self.file.flush()

# 启用重定向：替换系统输出为自定义类，指定TXT保存路径（可改文件名）
sys.stdout = ConsoleAndFileOutput('IP数据集五千episode最终结果随机种子+IDE_Block18+test4+CSA_Block修改后，使用f_loss1，删除fusion_align_loss的结果.txt')


# 2. 正确定义设备（自动使用唯一可用的GPU：cuda:0，无GPU则用CPU）
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
print(f"当前使用设备: {device}")  # 运行后会显示 "当前使用设备: cuda:0"，确认设备正确



# 忽略 NumPy 的 DeprecationWarning（np.object、np.float 相关）
warnings.filterwarnings("ignore", category=np.VisibleDeprecationWarning)
warnings.filterwarnings("ignore", category=DeprecationWarning)

# 忽略 PyTorch 的 UserWarning（.T 转置相关）
warnings.filterwarnings("ignore", category=UserWarning, message="The use of `x.T` on tensors of dimension other than 2")
import model.CSA_block
import scipy.io as io


#配置文件路径
parser = argparse.ArgumentParser(description="Few Shot Visual Recognition")
parser.add_argument('--config', type=str, default=os.path.join( './config', 'Indian_pines.py'),
                    help='config file with parameters of the experiment. '
                            'It is assumed that the config file is placed under the directory ./config')
args = parser.parse_args()

# Hyper Parameters
config = imp.load_source("", args.config).config
train_opt = config['train_config']
data_path = config['data_path']
save_path = config['save_path']
source_data = config['source_data']
target_data = config['target_data']
target_data_gt = config['target_data_gt']

patch_size = train_opt['patch_size']
emb_size = train_opt['d_emb']
SRC_INPUT_DIMENSION = train_opt['src_input_dim']
TAR_INPUT_DIMENSION = train_opt['tar_input_dim']
N_DIMENSION = train_opt['n_dim']
CLASS_NUM = train_opt['class_num']
SHOT_NUM_PER_CLASS = train_opt['shot_num_per_class']
QUERY_NUM_PER_CLASS = train_opt['query_num_per_class']
EPISODE = train_opt['episode']
LEARNING_RATE = train_opt['lr']
lambda_1 = train_opt['lambda_1']
lambda_2 = train_opt['lambda_2']
WEIGHT_DECAY = train_opt['weight_decay']     #权重衰减（L2正则化）
GPU = config['gpu']
TAR_CLASS_NUM = train_opt['TAR_CLASS_NUM'] # the number of class
TAR_LSAMPLE_NUM_PER_CLASS = train_opt['TAR_LSAMPLE_NUM_PER_CLASS'] # the number of labeled samples per class


#所有产生随机的地方，随机种子都设置成0
utils.same_seeds(0)







# load source data
#把source_data数据的内容存入到source_imdb变量中
with open(os.path.join(data_path, source_data), 'rb') as handle:
    source_imdb = pickle.load(handle)
#print(source_imdb.keys())
#print(source_imdb['Labels'])

# process source data
data_train = source_imdb['data']
labels_train = source_imdb['Labels']
#print(data_train.shape)
#print(labels_train.shape)
#得到一个干净有序的“类别索引表”
keys_all_train = sorted(list(set(labels_train)))  # class [0,...,18]
#print(keys_all_train) # [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18]
#方便后续对标签的处理
label_encoder_train = {}
for i in range(len(keys_all_train)):
    label_encoder_train[keys_all_train[i]] = i
#print(label_encoder_train) #{0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9, 10: 10, 11: 11, 12: 12, 13: 13, 14: 14, 15: 15, 16: 16, 17: 17, 18: 18}

#把“平铺”的样本列表，按类别号重新整理成“一个类别对应一堆样本路径”的字典
train_set = {}
for class_, path in zip(labels_train, data_train):
    if label_encoder_train[class_] not in train_set:
        train_set[label_encoder_train[class_]] = []
    train_set[label_encoder_train[class_]].append(path)
#print(train_set.keys())

data = train_set

#清理内存
del train_set
del keys_all_train
del label_encoder_train

#打印当前源域数据还剩多少类别
#print("Num classes for source domain datasets: " + str(len(data)))     #19
#打印出清理后“一个类别对应一堆样本路径”字典的键
#print(data.keys())     #dict_keys([5, 0, 8, 13, 7, 6, 4, 17, 10, 1, 3, 12, 16, 14, 2, 9, 11, 15, 18])

#每类只保留 ≥200 个样本，不够的类直接整类扔掉；返回过滤后的新字典。
data = utils.sanity_check(data) # 200 labels samples per class
#再看一次过滤后真正留下来的类别数。
#print("Num classes of the number of class larger than 200: " + str(len(data))) #18

#把每个样本的维度顺序从 “H×W×通道” 改成 “通道×H×W”，以适应 PyTorch 的格式要求。（对应mcmd中225-228）
for class_ in data:
    for i in range(len(data[class_])):
        image_transpose = np.transpose(data[class_][i], (2, 0, 1))
        data[class_][i] = image_transpose

#source 源域小样本分类数据存放在metatrain_data变量中
#metatrain_data与MCMD代码中的metatrain_data内容完全相同。
metatrain_data = data
print(len(metatrain_data.keys()), metatrain_data.keys())        #18 dict_keys([5, 0, 8, 13, 7, 6, 4, 17, 10, 1, 3, 12, 16, 14, 2, 9, 11, 15])
del data

# source domain adaptation data源域自适应数据
print(source_imdb['data'].shape)        #(77592, 9, 9, 128)
source_imdb['data'] = source_imdb['data'].transpose((1, 2, 3, 0))
print(source_imdb['data'].shape)        #(9, 9, 128, 77592)
print(source_imdb['Labels'])            #[ 5  0  8 ...  6 13 15]

## target data目标域数据
# load target data加载目标域数据

test_data = os.path.join(data_path,target_data)
test_label = os.path.join(data_path,target_data_gt)

Data_Band_Scaler, GroundTruth = utils.load_data(test_data, test_label)


#修改后的函数，为了适应支持集有16个类型，而查询集有304个类型
class ContrastiveLoss_middle(nn.Module):
    def __init__(self, device='cuda', temperature=0.1):  # ① 删掉 batch_size 形参
        super().__init__()
        self.register_buffer("temperature", torch.tensor(temperature).to(device))

    def forward(self, emb_i, emb_j):
        B = emb_i.shape[0]  # ② 运行时动态拿 B
        device = emb_i.device

        z_i = F.normalize(emb_i, dim=1)
        z_j = F.normalize(emb_j, dim=1)
        representations = torch.cat([z_i, z_j], dim=0)  # (2B, dim)

        similarity_matrix = euclidean_metric(representations, representations)  # (2B, 2B)

        sim_ij = torch.diag(similarity_matrix, B)
        sim_ji = torch.diag(similarity_matrix, -B)
        positives = torch.cat([sim_ij, sim_ji], dim=0)  # 2B

        nominator = torch.exp(positives / self.temperature)

        # ③ 现场生成 mask，形状随 B 变化
        negatives_mask = (~torch.eye(2 * B, 2 * B, dtype=bool, device=device)).float()
        denominator = negatives_mask * torch.exp(similarity_matrix / self.temperature)

        loss_partial = -torch.log(nominator / torch.sum(denominator, dim=1))
        loss = torch.sum(loss_partial) / (2 * B)
        return loss


class ContrastiveLoss(nn.Module):
    def __init__(self, batch_size, device='cuda', temperature = 0.1):
        super().__init__()
        self.batch_size = batch_size
        self.register_buffer("temperature", torch.tensor(temperature).to(device))  # 超参数 温度
        self.register_buffer("negatives_mask", (~torch.eye(batch_size * 2, batch_size * 2, dtype=bool).to(device)).float())  # 主对角线为0，其余位置全为1的mask矩阵

    def forward(self, emb_i, emb_j):  # emb_i, emb_j 是来自同一图像的两种不同的预处理方法得到
        z_i = F.normalize(emb_i, dim=1)  # (bs, dim)  --->  (bs, dim)
        z_j = F.normalize(emb_j, dim=1)  # (bs, dim)  --->  (bs, dim)

        representations = torch.cat([z_i, z_j], dim=0)  # repre: (2*bs, dim)
        # similarity_matrix = F.cosine_similarity(representations.unsqueeze(1), representations.unsqueeze(0), dim=-1)  # simi_mat: (2*bs, 2*bs)
        similarity_matrix = euclidean_metric(representations, representations) # simi_mat: (2*bs, 2*bs)

        sim_ij = torch.diag(similarity_matrix, self.batch_size)  # bs
        sim_ji = torch.diag(similarity_matrix, -self.batch_size)  # bs
        positives = torch.cat([sim_ij, sim_ji], dim=0)  # 2*bs

        nominator = torch.exp(positives / self.temperature)  # 2*bs
        denominator = self.negatives_mask * torch.exp(similarity_matrix / self.temperature)  # 2*bs, 2*bs

        loss_partial = -torch.log(nominator / torch.sum(denominator, dim=1))  # 2*bs
        loss = torch.sum(loss_partial) / (2 * self.batch_size)
        return loss

#这个是处理文本的loss的，不可以更改
infoNCE_Loss = ContrastiveLoss(batch_size = TAR_CLASS_NUM).to(device)     #对比损失，让相关的图像-文本特征靠近，不相关的远离


#这个是处理我新加的中间层特征的loss
infoNCE_Loss_middle = ContrastiveLoss_middle().to(device)

                                                        #----------------------------------新增的文本内容---------------------------
source_spa_text = [
    "Surfaces often exhibit a reflective and relatively uniform texture, with subtle spatial variations caused by natural ripples or minor surface irregularities, which are commonly associated with characteristic reflectance behavior in the near-infrared (NIR) band.",
    "Might show a compact and evenly distributed texture, sometimes with faint footprint-like patterns, frequently linked to higher reflectance in specific spectral bands due to surface compaction.",
    "May present an uneven texture influenced by recreational activity and inherent soil structure, which can manifest as distinguishable absorption behavior in the red and NIR regions depending on soil composition.",
    "Could display a rough and clumpy texture resulting from agricultural use and tillage, often correlating with reflectance variation related to moisture changes in the shortwave infrared (SWIR) band.",
    "Can exhibit a diverse range of textures, from fine grass-like patterns to denser shrub structures, producing variable spatial organization and corresponding changes in NIR reflectance with vegetation density.",
    "May appear as scattered and irregular textures within cultivated areas, reflecting human intervention and crop development stages, with spectral responses varying across growth phases.",
    "Typically show complex spatial textures due to mixed tree canopies and understory vegetation, where variations in vegetation height and density correspond to spectral differences in the red and NIR regions.",
    "Usually present a fine and even texture with slight variations in height and density, reflected in smooth spectral transitions within the NIR region, characteristic of well-maintained homogeneous surfaces.",
    "May display a uniform and grid-like texture indicative of cultivated rows, forming clear spatial patterns along with a noticeable spectral drop in the red-edge and NIR bands.",
    "Might exhibit a lighter and less dense texture during early growth stages, resulting in weaker reflectance in both visible and NIR bands compared with more mature vegetation.",
    "Can present structured and repetitive spatial textures aligned with planting direction, where spectral responses remain consistent across specific wavelength ranges.",
    "Often show a distinctly smooth and artificial texture typical of sports fields or paved surfaces, where uniform spatial appearance aligns with stable NIR reflectance from man-made materials.",
    "May exhibit varied spatial textures depending on material composition and surface condition, which directly influence spectral response across multiple bands.",
    "Can appear darker and more uniform in texture, commonly associated with asphalt or rooftops, which typically show low reflectance in the NIR region.",
    "Likely maintain a consistent and smooth spatial texture with minimal variation, corresponding to stable spectral responses under regular management conditions.",
    "May present a distinct and uniform texture associated with specific roofing or decorative materials, where spectral characteristics are primarily shaped by material composition.",
    "In areas such as sports grounds, surfaces often appear highly even and well maintained, with clear boundaries and a relatively homogeneous spectral signature.",
    "Common in roads and parking lots, these surfaces show hard and uniform textures with sharp spatial edges, frequently resulting in low NIR reflectance typical of urban materials."
]
source_spe_text = [
    "Exhibit relatively high reflectance in the near-infrared (NIR) band and lower reflectance in the shortwave infrared (SWIR) band, often associated with vegetation-covered or water-influenced surfaces.",
    "Spectral reflectance may increase in the NIR region due to surface compaction, leading to observable differences between urban-influenced soil and natural backgrounds.",
    "Bare soil spectra in park-like areas may retain weak vegetation characteristics, including mild chlorophyll absorption in the red band and moderate NIR reflectance.",
    "Farmland soil spectra often show clear sensitivity to moisture and organic matter, producing distinct absorption features and reflectance variation in the SWIR band.",
    "Typically show strong NIR reflectance characteristic of healthy vegetation, accompanied by relatively low reflectance in the SWIR region.",
    "Vegetation spectra may vary with growth stage and density, while consistently maintaining elevated reflectance peaks in the NIR band.",
    "Dense vegetation areas generally exhibit high reflectance, particularly in the NIR band, corresponding to forested or intensively cultivated regions.",
    "High NIR reflectance combined with a noticeable drop in the red-edge region is commonly observed, indicating healthy vegetation or dry surface conditions.",
    "Similar red-edge behavior is observed across rice growth stages, though slight spectral differences may arise depending on canopy structure.",
    "Early growth stages often show reduced visible reflectance and a developing NIR peak compared to fully mature vegetation.",
    "Row crops tend to exhibit distinctive NIR peaks that vary with phenological stage, differentiating them from grassland or forest spectra.",
    "Plastic-covered surfaces usually display suppressed reflectance due to material absorption, resulting in lower NIR values than natural vegetation.",
    "Non-dark artificial surfaces show moderate reflectance across bands, producing material-specific spectral signatures.",
    "Dark artificial materials typically demonstrate low reflectance in the NIR band with minimal spectral variation elsewhere.",
    "Certain artificial surfaces may show elevated reflectance in the blue band, forming distinct absorption behavior across visible and NIR wavelengths.",
    "Red-colored artificial materials often exhibit enhanced red-band reflectance, yielding unique urban spectral patterns.",
    "Artificial grass may resemble vegetation spectrally, though NIR reflectance is often lower and more stable than that of natural grass.",
    "Asphalt surfaces consistently show low reflectance across bands, especially in the NIR region, due to strong material absorption."
]
target_spa_text = [
    "Relatively even green surfaces with smooth spatial texture, often associated with consistent reflectance behavior across visible and NIR bands.",
    "Smooth and uniform vegetation distribution with minimal soil disturbance, resulting in limited spatial and spectral variability.",
    "Rough surfaces with shallow furrows and clod-like structures, reflecting tillage practices and corresponding to moisture-related spectral variation in the SWIR band.",
    "Standard corn textures with organized row patterns, where spectral differences emerge due to tillage intensity and reduced red-edge reflectance.",
    "Medium to fine and uniform textures commonly show high NIR reflectance, indicating consistent vegetation health and coverage.",
    "Grassland areas mixed with tree canopies produce irregular spatial patterns and intermediate spectral reflectance due to structural complexity.",
    "Mowed grass surfaces exhibit shorter and more consistent textures, leading to distinctive spectral responses with clear NIR peaks.",
    "Hay arranged in strip-like patterns forms strong directional textures, often corresponding to elevated NIR reflectance and reduced red-edge response.",
    "Uniform textures with clearly defined boundaries indicate well-separated land-cover regions with noticeable spectral transitions.",
    "Disordered and uneven textures reflect natural variability, producing complex and spatially inconsistent spectral responses.",
    "Naturally arranged but orderly textures show stable spatial patterns and consistent NIR reflectance typical of minimally disturbed vegetation.",
    "Highly regular and smooth textures are often linked to managed agricultural areas, resulting in stable spectral behavior across visible and NIR bands.",
    "Unified textures with limited internal variation commonly exhibit minimal NIR spectral fluctuation across samples.",
    "Complex textures arise from the mixture of vegetation and anthropogenic structures, leading to diverse spectral responses across bands.",
    "Highly irregular textures in mixed urban-natural areas result in strong spatial contrast and variable spectral behavior.",
    "Sharp edges and rigid spatial structures dominate urban surfaces, which are typically associated with low NIR reflectance."
]
target_spe_text = [
    "High near-infrared (NIR) reflectance combined with low shortwave infrared (SWIR) response is typical of healthy vegetated surfaces.",
    "Reflectance remains high in visible and NIR bands, followed by gradual decay in the SWIR region due to soil disturbance effects.",
    "Visible and NIR reflectance peaks may increase slightly due to crop residue, with a continuous decline observed in the SWIR band.",
    "Strong NIR reflectance accompanied by reduced red-edge response is characteristic of intensively managed agricultural land.",
    "Pasture areas often show pronounced red-edge behavior and elevated NIR reflectance, indicating active photosynthesis.",
    "Mixed grass and tree canopies produce intermediate reflectance values with increased spectral complexity across seasons.",
    "Mowed vegetation commonly shows a decrease in NIR reflectance related to reduced leaf area and canopy height.",
    "Dormant or harvested fields typically exhibit lower NIR reflectance compared with actively growing vegetation.",
    "Vegetation undergoing photosynthesis demonstrates high NIR reflectance with a clearly defined red-edge transition.",
    "Lower visible reflectance combined with increased NIR response is driven by chlorophyll absorption effects.",
    "Active vegetation exhibits a pronounced NIR peak with reduced visible-band reflectance.",
    "Strong NIR reflectance and a clear red-edge feature indicate healthy vegetation or moisture-influenced surfaces.",
    "High NIR reflectance with minimal inter-band variation reflects uniform vegetation conditions.",
    "Spectral responses vary widely in areas with mixed vegetation and artificial materials.",
    "Urban regions display complex spectral signatures due to the combination of vegetation and impervious surfaces.",
    "Low reflectance across most bands is typical of asphalt, concrete, or other high-absorption urban materials."
]









"""
第三版文本（目前效果最好）
source_spa_text=[     #源域空间文本描述
  "Surfaces often exhibit a reflective and relatively uniform texture, with subtle variations caused by natural ripples or waves, which correlate with distinct spectral reflectance patterns in the near-infrared (NIR) band.",
"Might show a compact and evenly distributed texture, potentially with footprint patterns, often linked to higher reflectance in specific spectral bands due to surface compactness.",
"May have an uneven texture due to recreational activities and natural soil structure, which could manifest in distinct absorption features in the red and NIR regions, depending on soil composition.",
"Could display a rough and clumpy texture, reflecting agricultural use and tillage, which correlates with variations in spectral reflectance, such as changes in moisture content in the SWIR region.",
"Can have a diverse range of textures, from fine grasses to denser shrubs, showing variable patterns that influence both spatial texture and spectral response, with changes in the NIR band related to vegetation density.",
"May appear as scattered and random textures within cultivated areas, reflecting human intervention and crop growth stages, with spectral responses varying by crop type and growth phases.",
"Typically show complex textures due to the mix of tree canopies and understory vegetation, where changes in vegetation height and density correlate with spectral differences in the red and NIR regions.",
"Usually have a fine and even texture, with subtle variations in height and density, which are reflected in smooth spectral curves in the NIR region, characteristic of well-maintained, homogeneous areas.",
"May display a uniform and grid-like texture, indicative of cultivated rows, with clear patterns in both the spatial domain and a distinct spectral drop in the red edge and NIR bands.",
"Might exhibit a lighter and less dense texture, as crops are just beginning to grow, leading to weaker reflectance in the visible and NIR bands, as compared to mature crops.",
"Can present a structured and repeated texture pattern, following the lines of planting, where spectral features correspond with crop rows, showing consistent reflectance in specific wavelengths.",
"Often show a distinct smooth and artificial texture, commonly found in sports fields and paved areas, where uniform reflectance in the NIR band correlates with man-made materials.",
"May have a varied texture depending on the material and surface characteristics, which also affects spectral response, with specific spectral features appearing based on material composition.",
"Can exhibit a more uniform and darker texture, often associated with materials like asphalt or rooftops, which are characterized by low reflectance in the NIR region.",
"Likely show a consistent and smooth texture, with a minimal spectral response variation, indicating consistent surface characteristics and regular management practices.",
"May have a distinct and uniform texture, possibly including certain types of roofing or decorative elements, where spectral patterns are shaped by material composition.",
"Such as sports fields, may have a very even and well-maintained texture, with clear delineations between areas, corresponding to a homogeneous spectral signature with minimal variation.",
"Common in roads and parking lots, have a hard and uniform texture with clear, sharp edges, often resulting in low reflectance in the NIR band, typical of urban and man-made surfaces."

]

target_spa_text = [
    "Relatively even green areas, with a smooth texture, often showing consistent reflectance across visible and NIR bands, indicating well-maintained grassland or turf.",
"Smooth surface with uniform vegetation distribution, no visible furrows or soil disturbance, leading to minimal variation in spectral reflectance, especially in the NIR and visible regions.",
"Rough surface with shallow furrows, soil clods, and strip-shaped tillage textures, reflecting agricultural practices, which correlate with spectral features in the SWIR band related to soil moisture and organic content.",
"Standard corn texture, less pronounced than minimally tilled corn, where spectral differences may emerge due to tillage intensity, with a noticeable drop in reflectance in the red edge region.",
"Medium to fine, uniform texture, often showing high reflectance in the NIR band, corresponding with vegetation health and uniform crop distribution.",
"Grassland interspersed with trees, showing irregular and variable texture, resulting in intermediate spectral reflectance values, with complex patterns due to the presence of both grass and tree canopies.",
"Mowed grass shows a shorter, more consistent texture, with a flatter vertical structure, leading to a distinct spectral signature, with clear peaks in the NIR band.",
"Hay neatly piled in the field, with distinct strip-like textures, resulting in high reflectance in the NIR region and a characteristic drop in the red edge.",
"Uniform texture with clear boundaries, indicating well-defined areas, often corresponding with urban or agricultural zones, where spectral patterns show clear transitions.",
"Disordered texture with an uneven, non-uniform surface, reflecting natural variability, resulting in complex spectral features that vary by vegetation and surface roughness.",
"Natural texture arranged in a more orderly, uniform manner, with consistent spectral reflectance patterns, especially in the NIR band, typical of grasslands and minimally disturbed environments.",
"Very consistent and regular texture with a smoother surface, usually linked to consistent vegetation or crop management practices, resulting in a stable spectral response in both visible and NIR bands.",
"Unified, regular texture, often seen in grasslands or crop fields, with minimal spectral variation in the NIR region, indicating uniform vegetation types and growth stages.",
"Complex textural features, often resulting from a mixture of vegetation and anthropogenic structures, leading to a wide range of spectral characteristics across multiple bands.",
"A mix of man-made structures and natural elements can lead to highly complex, irregular textures, especially in urban areas, where spectral responses vary greatly depending on the materials present.",
"Forming sharp edges and distinct structural textures, typically seen in urban zones, where low reflectance in the NIR band is characteristic of asphalt or concrete surfaces."

]

source_spe_text=["Exhibit high reflectance in the near-infrared (NIR) band and lower reflectance in the shortwave infrared (SWIR) band, indicating healthy vegetation or water bodies.",
"The spectral reflectance of bare soil in schools may be higher in the near-infrared region because compacted soil reflects more near-infrared light, leading to variations in spectral response between natural and urban areas.",
"The spectrum of bare soil in parks may exhibit more vegetation characteristics, such as chlorophyll absorption bands, especially in the red and near-infrared regions, indicating the presence of low-density vegetation.",
"The spectrum of bare soil in farmland may show clear changes in soil moisture and organic matter content, which are manifested in the spectrum as specific absorption features and changes in reflectance, especially in the SWIR band.",
"Shows high reflectance in the NIR band, characteristic of healthy vegetation, with low reflectance in the SWIR band, typical of dry soil or water bodies.",
"Shows high reflectance in the NIR band but may differ in reflectance depending on growth stages and density, with mature vegetation showing distinct reflectance peaks.",
"Exhibit high reflectance, especially in the NIR band, corresponding to areas with dense vegetation, such as forests or cultivated crops.",
"Show high reflectance in the NIR band and a significant drop in reflectance in the red edge region, indicating healthy vegetation or dry, non-vegetated areas.",
"Show high reflectance in the NIR band and a significant drop in reflectance in the red edge region, but may differ slightly due to specific growth stages of the rice crop.",
"Early growth stage rice fields may spectrally differ from mature stages, especially in vegetation indices, with lower reflectance in the visible spectrum and a sharp peak in the NIR region.",
"Row crops like corn or beans may spectrally differ from forests or grasslands, especially at different growth stages, with distinct peaks in the NIR region.",
"Plastic greenhouses may exhibit low reflectance due to the material's absorption rather than reflection of light, showing reduced NIR reflectance compared to natural vegetation.",
"Non-dark man-made objects like buildings may show moderate reflectance, depending on the material and surface characteristics, leading to unique spectral signatures.",
"Dark man-made objects like asphalt or dark roofs typically show low reflectance in the NIR band, with minimal variation across other spectral bands.",
"Blue man-made objects like swimming pools may have higher reflectance in the blue band, showing distinct absorption features in the blue and NIR regions.",
"Red man-made objects may have higher reflectance in the red band, leading to unique spectral signatures in urban environments.",
"Artificial grass, such as for decorative or sports fields, may spectrally resemble natural grass but differ due to the material used, with lower reflectance in the NIR region compared to natural grass.",
"Asphalt surfaces typically show low reflectance, especially in the NIR band, reflecting the material's high absorption capacity."
]

target_spe_text = [
    "Shows high near-infrared (NIR) reflectance, characteristic of healthy vegetation, such as grasslands or forests, with low reflectance in the SWIR band.",
"High reflectance in visible and near-infrared bands with continuous decay in short-wave infrared, slightly reduced intensity due to soil disturbance, often linked to agricultural lands.",
"High reflectance in visible and near-infrared bands with slightly higher peaks due to stubble retention, followed by continuous decay in short-wave infrared, indicating agricultural areas post-harvest.",
"Exhibits strong reflectance in the NIR band and lower reflectance in the red edge, characteristic of agricultural land or healthy vegetation.",
"Pasture lands reflect more light in the NIR region, showing a pronounced red edge, indicating healthy vegetation and strong photosynthetic activity.",
"Mixed grass and tree canopies result in intermediate reflectance values between grasslands and forests, with complex patterns due to different vegetation types and seasonal changes.",
"Mowed pastures exhibit a different spectral response due to reduced vegetation height and possible leaf structure changes, leading to a dip in the NIR reflectance.",
"Lower reflectance in the NIR band compared to actively growing vegetation, indicating dormancy or the cessation of growth, typical of dry or harvested fields.",
"High reflectance in the NIR band with a noticeable red edge, characteristic of vegetation undergoing photosynthetic activity, such as grasslands or forests.",
"Shows spectral response with lower reflectance in the visible spectrum and higher reflectance in the NIR region due to chlorophyll absorption, indicating healthy vegetation.",
"Reflectance is lower in the visible light region, with a pronounced peak in the near-infrared (NIR) region, typical of green vegetation and active photosynthesis.",
"Shows high NIR reflectance and a pronounced red edge, indicating the transition from visible to NIR bands, characteristic of healthy vegetation or wetland areas.",
"Shows high reflectance in the NIR bans4sd with a distinct red edge, reflecting a drop in reflectance from red to NIR bands, typical of vegetation health.",
"High NIR reflectance with lower reflectance in the red band, exhibiting a variety of spectral characteristics depending on plant type, health, and environmental conditions.",
"Urban areas with a mix of buildings, grass, trees, and driveways will have a complex spectral signature with a wide range of reflectance values across different bands.",
"Lower reflectance across most spectral bands due to material properties of urban surfaces like asphalt, concrete, or synthetic materials, which absorb more light."

]
"""








from transformers import BertModel, BertTokenizer

model = BertModel.from_pretrained('bert-base-uncased')  # base 768 large 768
model.eval()
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')

# 输入
# 利用bert将总结好的源域和目标域的光谱文本描述和空间文本描述变成机器可识别的向量
w1 = tokenizer(source_spa_text, padding=True, truncation=True, return_tensors='pt')
with torch.no_grad():
    outputs_w1 = model(**w1)
outputs_w1_src = outputs_w1.last_hidden_state[:, 0, :]  # (num_classess, 768)

w2 = tokenizer(target_spa_text, padding=True, truncation=True, return_tensors='pt')
with torch.no_grad():
    outputs_w2 = model(**w2)
outputs_w2_tar = outputs_w2.last_hidden_state[:, 0, :]  # (num_classess, 768)

g1 = tokenizer(source_spe_text, padding=True, truncation=True, return_tensors='pt')
with torch.no_grad():
    outputs_g1 = model(**g1)
outputs_g1_src = outputs_g1.last_hidden_state[:, 0, :]  # (num_classess, 768)

g2 = tokenizer(target_spe_text, padding=True, truncation=True, return_tensors='pt')
with torch.no_grad():
    outputs_g2 = model(**g2)
outputs_g2_tar = outputs_g2.last_hidden_state[:, 0, :]  # (num_classess, 768)

#代码在什么设别上跑
outputs_w1_src =outputs_w1_src.cpu().numpy()
outputs_w2_src =outputs_w2_tar.cpu().numpy()
outputs_g1_src =outputs_g1_src.cpu().numpy()
outputs_g2_src =outputs_g2_tar.cpu().numpy()



                                                                            #--------------------------新增的文本内容结束---------------------------




# get train_loader and test_loader
#这两个函数实现了目标域少样本数据从原始格式到元任务可用格式，第一个函数用于底层处理，第二个函数用于上层加工，
#get_train_test_loader函数输入：
    #Data_Band_Scaler：目标域原始高光谱数据
    #GroundTruth:目标域原始高光谱数据对应的标签
    #class_num:目标域的类别总数
    #shot_num_per_class：目标域中使用支持集的少量样本训练模型的样本数是多少（在Indian_pines.py文件中设置为1）
    #HalfWidth：用于裁剪目标域高光谱数据为局部图像块
#get_train_test_loader函数输出：
    #train_loader：包含所有目标域支持集样本（可以随便从里面选数据作为目标域的支持集）
    #test_loader：包含所有目标域查询集样本（目标域每个类别中除支持集以外的已标注数据）
    #imdb_da_train：通过“样本重复 + 辐射噪声” 增强后的train_loader
    #G：“扩大裁剪”（在原始图像基础上向外扩展HalfWidth个像素），本质是人为 “补全” 边缘区域，让原本处于边缘的像素也能被包裹在一个足够大的范围内
    #RandPerm：记录原始样本的打乱顺序，确保数据划分的随机性
    #Row：目标域带标签样本的行 / 列坐标索引
    #Column,nTrain：目标域训练样本总数

def get_train_test_loader(Data_Band_Scaler, GroundTruth, class_num, tar_lsample_num_per_class, shot_num_per_class, HalfWidth,test2=False):

    print(Data_Band_Scaler.shape)  # (610, 340, 103)
    [nRow, nColumn, nBand] = Data_Band_Scaler.shape

    '''label start'''
    num_class = int(np.max(GroundTruth))
    data_band_scaler = utils.flip_optimized(Data_Band_Scaler,HalfWidth)
    groundtruth = utils.flip_optimized(GroundTruth,HalfWidth)
    del Data_Band_Scaler
    del GroundTruth
    G=groundtruth
    data=data_band_scaler
    # HalfWidth
    # G = groundtruth[nRow - HalfWidth:2 * nRow + HalfWidth, nColumn - HalfWidth:2 * nColumn + HalfWidth]
    # data = data_band_scaler[nRow - HalfWidth:2 * nRow + HalfWidth, nColumn - HalfWidth:2 * nColumn + HalfWidth, :]

    [Row, Column] = np.nonzero(G)
    # print(Row)
    del data_band_scaler
    del groundtruth

    nSample = np.size(Row)
    print('number of sample', nSample)

    # Sampling samples
    train = {}
    test = {}
    da_train = {}  # Data Augmentation
    m = int(np.max(G))
    nlabeled = tar_lsample_num_per_class  # 5   nlabeled和shot_num_per_class都是通过TAR_LSAMPLE_NUM_PER_CLASS赋值的，相等。
    print('labeled number per class:', nlabeled)
    print((200 - nlabeled) / nlabeled + 1)  # 40
    print(math.ceil((200 - nlabeled) / nlabeled) + 1)

    for i in range(m):
        indices = [j for j, x in enumerate(Row.ravel().tolist()) if G[Row[j], Column[j]] == i + 1]
        np.random.shuffle(indices)
        nb_val = shot_num_per_class
        train[i] = indices[:nb_val]
        da_train[i] = []
        for j in range(math.ceil((200 - nlabeled) / nlabeled) + 1):
            da_train[i] += indices[:nb_val]
        test[i] = indices[nb_val:]

    train_indices = []
    test_indices = []
    da_train_indices = []
    for i in range(m):
        train_indices += train[i]
        test_indices += test[i]
        da_train_indices += da_train[i]
    np.random.shuffle(test_indices)

    print('the number of train_indices:', len(train_indices))  # 520 应该不是这个结果，输出检查！
    print('the number of test_indices:', len(test_indices))  # 9729
    print('the number of train_indices after data argumentation:', len(da_train_indices))  # 520
    print('labeled sample indices:', train_indices)

    nTrain = len(train_indices)
    nTest = len(test_indices)
    da_nTrain = len(da_train_indices)

    imdb = {}
    imdb['data'] = np.zeros([2 * HalfWidth + 1, 2 * HalfWidth + 1, nBand, nTrain + nTest],
                            dtype=np.float32)  # (9,9,100,n)
    imdb['Labels'] = np.zeros([nTrain + nTest], dtype=np.int64)
    imdb['set'] = np.zeros([nTrain + nTest], dtype=np.int64)
    imdb['index']=np.zeros([nTrain + nTest], dtype=np.int64)
    RandPerm = train_indices + test_indices

    RandPerm = np.array(RandPerm)

    # for iSample in range(nTrain + nTest):
    #     imdb['data'][:, :, :, iSample] = data[
    #                                      Row[RandPerm[iSample]] - HalfWidth : Row[RandPerm[iSample]] + HalfWidth + 1,
    #                                      Column[RandPerm[iSample]] - HalfWidth : Column[RandPerm[iSample]] + HalfWidth + 1,
    #                                      :]
    #     imdb['Labels'][iSample] = G[Row[RandPerm[iSample]], Column[RandPerm[iSample]]].astype(np.int64)
    imdb['data']=data
    imdb['Labels'] = G-1
    imdb['index']=RandPerm
    imdb['Row']= Row
    imdb['Column']=Column
    imdb['set'] = np.hstack((np.ones([nTrain]), 3 * np.ones([nTest]))).astype(np.int64)
    imdb['HalfWidth']=HalfWidth
    print('Data is OK.')

    train_dataset = utils.matcifar(imdb, train=True, d=3, medicinal=0)
    train_loader = torch.utils.data.DataLoader(train_dataset, batch_size=class_num * shot_num_per_class, shuffle=False, num_workers=0)
    #train_loader2 = torch.utils.data.DataLoader(train_dataset, batch_size=1024, shuffle= False)
    del train_dataset

    test_dataset = utils.matcifar(imdb, train=False, d=3, medicinal=0)
    test_loader = torch.utils.data.DataLoader(test_dataset, batch_size=512, shuffle=False, num_workers=0)
    #test_loader2 = torch.utils.data.DataLoader(test_dataset, batch_size=304, shuffle=False)
    del test_dataset
    del imdb

    # Data Augmentation for target domain for training
    imdb_da_train = {}
    imdb_da_train['data'] = np.zeros([2 * HalfWidth + 1, 2 * HalfWidth + 1, nBand, da_nTrain],
                                     dtype=np.float32)  # (9,9,100,n)
    imdb_da_train['Labels'] = np.zeros([da_nTrain], dtype=np.int64)
    imdb_da_train['set'] = np.zeros([da_nTrain], dtype=np.int64)

    da_RandPerm = np.array(da_train_indices)
    for iSample in range(da_nTrain):
        # imdb_da_train['data'][:, :, :, iSample] = data_augment.Crop_and_resize_single(
        #     data[Row[da_RandPerm[iSample]] - HalfWidth: Row[da_RandPerm[iSample]] + HalfWidth + 1,
        #     Column[da_RandPerm[iSample]] - HalfWidth: Column[da_RandPerm[iSample]] + HalfWidth + 1, :], HalfWidth)
        imdb_da_train['data'][:, :, :, iSample] = data_augment.radiation_noise(
            data[Row[da_RandPerm[iSample]] - HalfWidth: Row[da_RandPerm[iSample]] + HalfWidth + 1,
            Column[da_RandPerm[iSample]] - HalfWidth: Column[da_RandPerm[iSample]] + HalfWidth + 1, :])

        imdb_da_train['Labels'][iSample] = G[Row[da_RandPerm[iSample]], Column[da_RandPerm[iSample]]].astype(np.int64)
    imdb_da_train['Labels'] = imdb_da_train['Labels'] - 1  # 1-10 0-9
    imdb_da_train['set'] = np.ones([da_nTrain]).astype(np.int64)
    print('ok')
    if test2:
     return train_loader, test_loader, imdb_da_train, G, RandPerm, Row, Column, nTrain
    return train_loader, test_loader, imdb_da_train, G, RandPerm, Row, Column, nTrain

#get_target_dataset函数的输入：
    #Data_Band_Scaler：输入的目标域高光谱图像数据
    #GroundTruth:目标域原始高光谱数据对应的标签
    #class_num:目标域的类别总数
    #shot_num_per_class：目标域中使用支持集的少量样本训练模型的样本数是多少（在Indian_pines.py文件中设置为1）
    #HalfWidth：用于裁剪目标域高光谱数据为局部图像块
def get_target_dataset(Data_Band_Scaler, GroundTruth, class_num, tar_lsample_num_per_class, shot_num_per_class, patch_size,test2=False,aug=False):
    if test2:
     train_loader, test_loader, imdb_da_train, G, RandPerm, Row, Column, nTrain= get_train_test_loader(
        Data_Band_Scaler=Data_Band_Scaler,
        GroundTruth=GroundTruth,
        class_num=class_num,
        tar_lsample_num_per_class=tar_lsample_num_per_class,
        shot_num_per_class=shot_num_per_class,
        HalfWidth=patch_size // 2,test2=test2)
    else:
        train_loader, test_loader, imdb_da_train, G, RandPerm, Row, Column, nTrain= get_train_test_loader(
            Data_Band_Scaler=Data_Band_Scaler,
            GroundTruth=GroundTruth,
            class_num=class_num,
            tar_lsample_num_per_class=tar_lsample_num_per_class,
            shot_num_per_class=shot_num_per_class,
            HalfWidth=patch_size // 2, test2=test2)
    train_datas, train_labels,indexs = next(train_loader.__iter__())
    print('train labels:', train_labels)
    print('size of train datas:', train_datas.shape)

    print(imdb_da_train.keys())
    print(imdb_da_train['data'].shape)
    print(imdb_da_train['Labels'])
    del Data_Band_Scaler, GroundTruth

    # target data with data augmentation
    target_da_datas = np.transpose(imdb_da_train['data'], (3, 2, 0, 1))  # 换坐标轴 (9,9,103, 1800)->(1800, 103, 9, 9)
    print(target_da_datas.shape)
    target_da_labels = imdb_da_train['Labels']
    print('target data augmentation label:', target_da_labels)

    # metatrain data for few-shot classification 和之前的区别就是，把多维数组按类别划分为字典。
    # target_da_train_set = {}
    # for class_, path in zip(target_da_labels, target_da_datas):
    #     if class_ not in target_da_train_set:
    #         target_da_train_set[class_] = []
    #     target_da_train_set[class_].append(path)
    # target_da_metatrain_data = target_da_train_set
    # print(target_da_metatrain_data.keys())


    # metatrain data for few-shot classification 和之前的区别就是，把多维数组按类别划分为字典。
    target_da_train_set = {}
    target_aug_data_ssl = [] # target aug dataset. loader包含相同样本的增强
    target_aug_label_ssl = [] # target aug dataset. loader包含相同样本的增强

    for class_, path in zip(target_da_labels, target_da_datas):
        if class_ not in target_da_train_set:
            target_da_train_set[class_] = []
        target_da_train_set[class_].append(path)
        target_aug_data_ssl.append(path)
        target_aug_label_ssl.append(class_)
    target_da_metatrain_data = target_da_train_set
    print("aaaaaaaa:",target_da_metatrain_data.keys())
    if aug and test2:
        return train_loader, test_loader, target_da_metatrain_data, G, RandPerm, Row, Column, nTrain,target_aug_data_ssl, target_aug_label_ssl
    if test2:
     return train_loader, test_loader, target_da_metatrain_data, G, RandPerm, Row, Column, nTrain,target_aug_data_ssl, target_aug_label_ssl
    else:
        return train_loader, test_loader, target_da_metatrain_data, G, RandPerm, Row, Column, nTrain,target_aug_data_ssl, target_aug_label_ssl


# model
#定义了一个3D卷积块
def conv3x3x3(in_channel, out_channel):
    layer = nn.Sequential(
        nn.Conv3d(in_channels=in_channel,out_channels=out_channel,kernel_size=3, stride=1,padding=1,bias=False),
        nn.BatchNorm3d(out_channel),
        # nn.ReLU(inplace=True)
    )
    return layer

def conv3x3x3_ft(in_channel, out_channel):
    layer = nn.Sequential(
        nn.Conv3d(in_channels=in_channel,out_channels=out_channel,kernel_size=3, stride=1,padding=1,bias=False),
        FeatureWiseTransformation2d_fw(out_channel),
        # nn.ReLU(inplace=True)
    )
    return layer

#是一个3D残差块，堆叠了3个3D卷积层
class residual_block(nn.Module):

    def __init__(self, in_channel,out_channel):
        super(residual_block, self).__init__()

        self.conv1 = conv3x3x3(in_channel,out_channel)
        self.conv2 = conv3x3x3(out_channel,out_channel)
        self.conv3 = conv3x3x3(out_channel,out_channel)

    def forward(self, x): #(1,1,100,9,9)
        x1 = F.relu(self.conv1(x), inplace=True) #(1,8,100,9,9)  (1,16,25,5,5)
        x2 = F.relu(self.conv2(x1), inplace=True) #(1,8,100,9,9) (1,16,25,5,5)
        x3 = self.conv3(x2) #(1,8,100,9,9) (1,16,25,5,5)

        out = F.relu(x1+x3, inplace=True) #(1,8,100,9,9)  (1,16,25,5,5)
        return out

# --- feature-wise transformation layer ---
#特征转换层
def softplus(x):
  return torch.nn.functional.softplus(x, beta=100)

#带动态特征增强的批归一化层，能解决 “数据分布偏移” 和 “样本量少” 的问题
class FeatureWiseTransformation2d_fw(nn.BatchNorm2d):
  feature_augment = True
  def __init__(self, num_features, momentum=0.1, track_running_stats=True):
    super(FeatureWiseTransformation2d_fw, self).__init__(num_features, momentum=momentum, track_running_stats=track_running_stats)
    self.weight.fast = None
    self.bias.fast = None
    if self.track_running_stats:
      self.register_buffer('running_mean', torch.zeros(num_features))
      self.register_buffer('running_var', torch.zeros(num_features))
    if self.feature_augment: # initialize {gamma, beta} with {0.3, 0.5}
      self.gamma = torch.nn.Parameter(torch.ones(1, num_features, 1, 1, 1)*0.3)
      self.beta  = torch.nn.Parameter(torch.ones(1, num_features, 1, 1, 1)*0.5)
    self.reset_parameters()

  def reset_running_stats(self):
    if self.track_running_stats:
      self.running_mean.zero_()
      self.running_var.fill_(1)

  def forward(self, x, step=0):
    if self.weight.fast is not None and self.bias.fast is not None:
      weight = self.weight.fast
      bias = self.bias.fast
    else:
      weight = self.weight
      bias = self.bias
    if self.track_running_stats:
      out = F.batch_norm(x, self.running_mean, self.running_var, weight, bias, training=self.training, momentum=self.momentum)
    else:
      out = F.batch_norm(x, torch.zeros_like(x), torch.ones_like(x), weight, bias, training=True, momentum=1)

    # apply feature-wise transformation
    if self.feature_augment and self.training:
      gamma = (1 + torch.randn(1, self.num_features, 1, 1, 1, dtype=self.gamma.dtype, device=self.gamma.device)*softplus(self.gamma)).expand_as(out)
      beta = (torch.randn(1, self.num_features, 1, 1, 1, dtype=self.beta.dtype, device=self.beta.device)*softplus(self.beta)).expand_as(out)
      out = gamma*out + beta
    return out

#从高光谱数据中提取多尺度空间 - 光谱联合特征
class D_Res_3d_CNN(nn.Module):
    def __init__(self, in_channel, out_channel1, out_channel2, patch_size, emb_size):
        super(D_Res_3d_CNN, self).__init__()
        self.in_channel = in_channel
        self.emb_size = emb_size
        self.patch_size = patch_size
        self.block1 = residual_block(in_channel,out_channel1)
        self.maxpool1 = nn.MaxPool3d(kernel_size=(4,2,2),padding=(0,1,1),stride=(4,2,2))
        self.block2 = residual_block(out_channel1,out_channel2)
        self.maxpool2 = nn.MaxPool3d(kernel_size=(4,2,2),stride=(4,2,2), padding=(2,1,1))
        self.conv = nn.Conv3d(in_channels=out_channel2,out_channels=32,kernel_size=3, bias=False)

        self.layer_second = nn.Sequential(nn.Linear(in_features=self._get_layer_size()[0],
                                                    out_features=self.emb_size,
                                                    bias=True),
                                          nn.BatchNorm1d(self.emb_size))

        self.layer_last = nn.Sequential(nn.Linear(in_features=self._get_layer_size()[1],
                                                  out_features=self.emb_size,
                                                  bias=True),
                                        nn.BatchNorm1d(self.emb_size))
                                        
    def _get_layer_size(self):
        with torch.no_grad():
            x = torch.zeros((1,1, 100,
                             self.patch_size, self.patch_size))
            x = self.block1(x)
            x = self.maxpool1(x)
            x = self.block2(x)
            x = self.maxpool2(x)
            _, t, c, w, h = x.size()
            s1 = t * c * w * h
            x = self.conv(x)
            x = x.view(x.shape[0],-1)
            s2 = x.size()[1]
        return s1, s2

    def forward(self, x): 
        x = x.unsqueeze(1) 
        x = self.block1(x) 
        x = self.maxpool1(x) 
        x = self.block2(x)
        x = self.maxpool2(x)
        inter = x
        inter = inter.view(inter.shape[0],-1)
        inter = self.layer_second(inter)
        x = self.conv(x)
        x = x.view(x.shape[0],-1) 
        x = self.layer_last(x)
        out = []
        out.append(inter)
        out.append(x)
        return out

#实现特征通道维度的转换与标准化
class Mapping(nn.Module):
    def __init__(self, in_dimension, out_dimension):
        super(Mapping, self).__init__()
        self.preconv = nn.Conv2d(in_dimension, out_dimension, 1, 1, bias=False)
        self.preconv_bn = nn.BatchNorm2d(out_dimension)

    def forward(self, x):
        x = self.preconv(x)
        x = self.preconv_bn(x)
        return x

#定义特征提取网络，将源域/目标域的高光谱数据转换为统一维度的特征空间，解决域偏移导致的特征分布差异
class Network(nn.Module):
    def __init__(self, patch_size, emb_size):
        super(Network, self).__init__()
        self.feature_encoder = D_Res_3d_CNN(1,8,16,patch_size, emb_size)
        self.target_mapping = Mapping(TAR_INPUT_DIMENSION, N_DIMENSION)
        self.source_mapping = Mapping(SRC_INPUT_DIMENSION, N_DIMENSION)

    def forward(self, x, domain='source'):
        if domain == 'target':
            x = self.target_mapping(x)
        elif domain == 'source':
            x = self.source_mapping(x)
        feature = self.feature_encoder(x)
        return feature

#模型参数初始化函数
def weights_init(m):
    classname = m.__class__.__name__
    if classname.find('Conv') != -1:
        nn.init.xavier_uniform_(m.weight, gain=1)
        if m.bias is not None:
            m.bias.data.zero_()
    elif classname.find('BatchNorm') != -1:
        nn.init.normal_(m.weight, 1.0, 0.02)
        m.bias.data.zero_()
    elif classname.find('Linear') != -1:

        nn.init.xavier_normal_(m.weight)
        if m.bias is not None:
            m.bias.data = torch.ones(m.bias.data.size())

#将交叉熵损失（Cross-Entropy Loss）和带sigmoid 的二值交叉熵损失（Binary Cross-Entropy with Logits）放到gpu上运行
crossEntropy = nn.CrossEntropyLoss().to(GPU)
domain_criterion = nn.BCEWithLogitsLoss().to(GPU)

#计算两个特征集合之间的负欧氏距离
def euclidean_metric(a, b):
    n = a.shape[0]
    m = b.shape[0]
    a = a.unsqueeze(1).expand(n, m, -1)
    b = b.unsqueeze(0).expand(n, m, -1)
    logits = -((a - b)**2).sum(dim=2)
    return logits


RS=SRC_INPUT_DIMENSION//16-1         #源域分割参数（用于输入维度计算）
RT=TAR_INPUT_DIMENSION//16-1         #目标域分割参数
def preprocess_data(query_set, query_labels):
    """
    预处理数据，按类别分组。

    """
    data_by_class = {i: [] for i in range(TAR_CLASS_NUM)}
    for idx, label in enumerate(query_labels):
        data_by_class[label.item()].append(idx)

    return data_by_class
#互帮9*9图像分割成4个5*5图像，为了多维知识蒸馏做准备
def split_tensor(input_tensor):
    N, C, H, W = input_tensor.shape
    if H != 9 or W != 9:
        raise ValueError("Each patch must be of size (9, 9).")

    # 提取四个角落的子patch
    patches_per_image =torch.cat([
        input_tensor[:, :, :5, :5],   # 左上
        input_tensor[:, :, :5, 4:],   # 右上
        input_tensor[:, :, 4:, :5],   # 左下
        input_tensor[:, :, 4:, 4:]     # 右下
    ], dim=1)
    output_tensor = patches_per_image.view(N * 4, C, 5, 5)# 右下

    return output_tensor
#按光谱通道分组，创建重叠的光谱子集，为了多维知识蒸馏做准备
def split_tensor2(input_tensor,c_num):
    N, C, H, W = input_tensor.shape
    if H != 9 or W != 9:
        raise ValueError("Each patch must be of size (9, 9).")
    n_k=c_num//16-1

    patches_per_channel = torch.cat([
        input_tensor[:, i * 16:(i + 2) * 16, :, :]
        for i in range(n_k)
    ],dim=1)

    output_tensor = patches_per_channel.view(N * n_k, 32, 9, 9)

    return output_tensor

#这两个都是软交叉熵损失函数，在多维知识蒸馏步骤中处理概率分布之间的相似性
#处理类别维度的概率分布
def soft_cross_entropy(input, target, reduction='sum'):

    log_prob = F.log_softmax(input, dim=1)
    loss = -torch.mean(target * log_prob, dim=1)

    if reduction == 'mean':
        return torch.mean(loss)
    elif reduction == 'sum':
        return torch.sum(loss)
    else:
        return loss
#处理最后一个维度的概率分布
def soft_cross_entropy2(input, target, reduction='sum'):

    log_prob = F.log_softmax(input, dim=-1)
    loss = -torch.mean(target * log_prob, dim=-1)

    if reduction == 'mean':
        return torch.mean(loss)
    elif reduction == 'sum':
        return torch.sum(loss)
    else:
        return loss
#多维知识蒸馏层
#计算局部特征（local predictions）和全局特征（global predictions）之间的蒸馏损失
def local_global_distillation_loss_flattened(global_preds, local_preds, R):


    assert global_preds.dim() == 2 and local_preds.dim() == 2, "输入张量维度不符合要求"
    N, C = global_preds.shape
    assert (R * N) == local_preds.shape[0] and C == local_preds.shape[1], "输入张量大小不匹配"

    global_preds_repeated = global_preds.repeat_interleave(R, dim=0)
    l = local_preds
    g = global_preds_repeated
    max_l = l.max(dim=-1, keepdim=True)[0]
    max_g = g.max(dim=-1, keepdim=True)[0]
    min_l = l.min(dim=-1, keepdim=True)[0]
    min_g = g.min(dim=-1, keepdim=True)[0]
    probabilities1 = (l - min_l) * 1.0 / (max_l - min_l)
    probabilities2 = (g - min_g) * 1.0 / (max_g - min_g)
    _, target_labels = torch.max(global_preds_repeated, dim=1)
    cross_entropy_loss = soft_cross_entropy(probabilities1, probabilities2)
    loss_sum = cross_entropy_loss.sum()

    L_self = loss_sum / (R * N)

    return L_self

    return L_cross

#不仅考虑了局部和全局特征之间的一致性，还引入了一个额外的步骤，以进一步增强局部特征和全局特征之间的对齐。
#让同一个类别的不同样本的局部特征与全局特征相互学习，增强特征的类内一致性。
def cross_image_local_global_distillation_loss_flattened2(query_labels, global_preds, local_preds_flattened,
                                                         data_by_class, R):

    N, C = global_preds.shape
    total_predictions = R * N
    assert local_preds_flattened.shape == (total_predictions, C), "输入张量大小不匹配"

    loss_sum = 0.0
    p1 = []
    p2 = []
    query_index = []
    for i in range(N):
        # 获取当前图像的类别

     current_label = query_labels[i]
        # 从当前类别中随机选择一个不同的索引
     other_indices = data_by_class[current_label.item()]
     for indices in other_indices:
         query_index.append(indices)

    local_indices = [R * q + r for q in query_index for r in range(R)]
    p1_tensors = local_preds_flattened[local_indices]
    p2_tensors = global_preds[[i for i in range(N)]].repeat_interleave(R*19, dim=0)
    l = p1_tensors
    g = p2_tensors
    max_l = l.max(dim=-1, keepdim=True)[0]
    max_g = g.max(dim=-1, keepdim=True)[0]
    min_l = l.min(dim=-1, keepdim=True)[0]
    min_g = g.min(dim=-1, keepdim=True)[0]
    probabilities1 = (l - min_l) * 1.0 / (max_l - min_l)
    probabilities2 = (g - min_g) * 1.0 / (max_g - min_g)

    cross_entropy_loss = soft_cross_entropy2(probabilities1, probabilities2)
    loss_sum += cross_entropy_loss

    # 平均所有样本的损失
    L_cross = loss_sum / (N * R*19)

    return L_cross

class tagetSSLDataset(Dataset):
    def __init__(self, image_datas, image_labels):
        self.image_datas = image_datas
        self.image_labels = image_labels

    def __len__(self):
        return len(self.image_datas)

    def __getitem__(self, idx):
        image = self.image_datas[idx]
        label = self.image_labels[idx]
        return image, label


class SupConLoss(nn.Module):
    def __init__(self, temperature=0.07, contrast_mode='all', base_temperature=0.07):
        super(SupConLoss, self).__init__()
        self.temperature = temperature
        self.contrast_mode = contrast_mode

        self.base_temperature = temperature

    def forward(self, features, labels=None, mask=None, device=0):
        if len(features.shape) < 3:
            raise ValueError('`features` needs to be [bsz, n_views, ...],'
                             'at least 3 dimensions are required')
        if len(features.shape) > 3:
            features = features.view(features.shape[0], features.shape[1], -1)

        batch_size = features.shape[0]
        if labels is not None and mask is not None:
            raise ValueError('Cannot define both `labels` and `mask`')
        elif labels is None and mask is None:
            mask = torch.eye(batch_size, dtype=torch.float32).to(device)
        elif labels is not None:
            labels = labels.contiguous().view(-1, 1)
            if labels.shape[0] != batch_size:
                raise ValueError('Num of labels does not match num of features')
            mask = torch.eq(labels, labels.T).float().to(device)
        else:
            mask = mask.float().to(device)

        contrast_count = features.shape[1]
        contrast_feature = torch.cat(torch.unbind(features, dim=1), dim=0)
        if self.contrast_mode == 'one':
            anchor_feature = features[:, 0]
            anchor_count = 1
        elif self.contrast_mode == 'all':
            anchor_feature = contrast_feature
            anchor_count = contrast_count
        else:
            raise ValueError('Unknown mode: {}'.format(self.contrast_mode))

        # compute logits
        anchor_dot_contrast = torch.div(
            torch.matmul(anchor_feature, contrast_feature.T),
            self.temperature)
        # for numerical stability
        logits_max, _ = torch.max(anchor_dot_contrast, dim=1, keepdim=True)
        logits = anchor_dot_contrast - logits_max.detach()

        # tile mask
        mask = mask.repeat(anchor_count, contrast_count)
        # mask-out self-contrast cases
        logits_mask = torch.scatter(
            torch.ones_like(mask),
            1,
            torch.arange(batch_size * anchor_count).view(-1, 1).to(device),
            0
        )
        mask = mask * logits_mask

        # compute log_prob
        exp_logits = torch.exp(logits) * logits_mask
        log_prob = logits - torch.log(exp_logits.sum(1, keepdim=True))

        # compute mean of log-likelihood over positive
        mean_log_prob_pos = (mask * log_prob).sum(1) / mask.sum(1)

        loss = - (self.temperature / self.base_temperature) * mean_log_prob_pos
        loss = loss.view(anchor_count, batch_size).mean()

        return loss

def class_conditional_fusion_alignment_loss(
    fusion_weights_src,
    fusion_weights_tar,
    labels_src,
    labels_tar,
    num_classes,
    temperature=1.0,
    reduction="batchmean"
):
    """
    类条件的跨域 fusion_weights 对齐损失

    Args:
        fusion_weights_src: Tensor [Ns, 2]
        fusion_weights_tar: Tensor [Nt, 2]
        labels_src: Tensor [Ns]
        labels_tar: Tensor [Nt]
        num_classes: int（语义类别数）
        temperature: float
        reduction: "mean" or "sum"

    Returns:
        loss: scalar
    """

    loss = 0.0
    valid_class_count = 0

    for c in range(num_classes):
        src_mask = (labels_src == c)
        tar_mask = (labels_tar == c)

        # 如果某一类在某个域缺失，跳过（few-shot 常见）
        if src_mask.sum() == 0 or tar_mask.sum() == 0:
            continue

        # 1. 取该类别下的 fusion weights
        fw_src_c = fusion_weights_src[src_mask]  # [n_sc, 2]
        fw_tar_c = fusion_weights_tar[tar_mask]  # [n_tc, 2]

        # 2. 类级平均（类的“融合策略原型”）
        fw_src_mean = fw_src_c.mean(dim=0, keepdim=True)  # [1, 2]
        fw_tar_mean = fw_tar_c.mean(dim=0, keepdim=True)  # [1, 2]

        # 3. softmax → 概率分布
        p_src = F.softmax(fw_src_mean / temperature, dim=1)
        p_tar = F.softmax(fw_tar_mean / temperature, dim=1)

        # 4. 对称 KL
        kl_src_tar = F.kl_div(p_src.log(), p_tar, reduction=reduction)
        kl_tar_src = F.kl_div(p_tar.log(), p_src, reduction=reduction)

        loss += 0.5 * (kl_src_tar + kl_tar_src)
        valid_class_count += 1

    if valid_class_count > 0:
        loss = loss / valid_class_count

    return loss


# run 10 times
#Alpha=0.1
nDataSet = 5   #进行十次独立实验，每次实验5000个
acc = np.zeros([nDataSet, 1])       # 每轮的准确率（包含十个准确率结果），可以通过计算平均数得到平均总体准确率（OAmean），也可以通过计算平均数得到准确率的标准差（OAstd），十次实验结果的波动程度
time_list = np.zeros([nDataSet, 1])    #按顺序记录多个数据集的时间指标
A = np.zeros([nDataSet, TAR_CLASS_NUM]) # 每轮每类的准确率，通过计算平均数得到每个实验的类别平均准确率（AAmean）
k = np.zeros([nDataSet, 1]) # Kappa，用于衡量分类结果与随机分类的差异程度(kmean)
best_predict_all = []    # 最好的预测结果，存什么
best_G, best_RandPerm, best_Row, best_Column, best_nTrain = None,None,None,None,None
#每格将来会放 一次 run 的类别映射表
class_map = np.zeros((nDataSet,), dtype=object)
#每格存 一次 run 测试集的特征矩阵
feature_emb_cell = np.zeros((nDataSet,), dtype=object)
#每格存 对应测试集的真实标签
test_labels_cell = np.zeros((nDataSet,), dtype=object)
#临时累加当前这次 run 的结果
test_labels_end, feature_emb_end = [], []

#设置随机种子
#seeds = [0, 1224, 1679, 1576, 1314, 3421, 3597, 6002, 1315, 7426]
#seeds=[0,1576,1224,1314,3421]
seeds = [1233,1567,1432,1567,1224]


#日志相关内容
logger = logging.getLogger('main')
logger.info('seeds_list:{}'.format(seeds))
out_channel = 128
Temp = 0.05
temp = 0.05

# 在训练开始前就创建，不要在 episode 内部创建！
# 把[16,24,48,9,9]转变成[16,128]
compress_layer11 = torch.nn.Linear(24 * 48 * 9 * 9, 128)
compress_layer11 = compress_layer11.to(device)
# 把[16,24,1,9,9]转变成[16,128]
compress_layer1 = torch.nn.Linear(24 * 1 * 9 * 9, 128)
compress_layer1 = compress_layer1.to(device)
# 把[16,24,48,9,9]转变成[16,128]
compress_layer22 = torch.nn.Linear(24 * 48 * 9 * 9, 128)
compress_layer22 = compress_layer22.to(device)
# 把[16,24,1,9,9]转变成[16,128]
compress_layer2 = torch.nn.Linear(24 * 1 * 9 * 9, 128)
compress_layer2 = compress_layer2.to(device)
# 把[16,24,48,9,9]转变成[16,128]
compress_layer33 = torch.nn.Linear(24 * 48 * 9 * 9, 128)
compress_layer33 = compress_layer33.to(device)
# 把[16,24,1,9,9]转变成[16,128]
compress_layer3 = torch.nn.Linear(24 * 1 * 9 * 9, 128)
compress_layer3 = compress_layer3.to(device)
# 把[16,24,48,9,9]转变成[16,128]
compress_layer44 = torch.nn.Linear(24 * 48 * 9 * 9, 128)
compress_layer44 = compress_layer44.to(device)
# 把[16,24,1,9,9]转变成[16,128]
compress_layer4 = torch.nn.Linear(24 * 1 * 9 * 9, 128)
compress_layer4 = compress_layer4.to(device)

def save_rng_state(round_id, save_dir="rng_states"):

    os.makedirs(save_dir, exist_ok=True)

    save_path = os.path.join(save_dir, f"rng_round_{round_id}.pt")

    rng_state = {
        "python": random.getstate(),
        "numpy": np.random.get_state(),
        "torch_cpu": torch.get_rng_state(),
        "torch_cuda": torch.cuda.get_rng_state_all() if torch.cuda.is_available() else None
    }

    torch.save(rng_state, save_path)

    print(f"[Saved RNG] Round {round_id} -> {save_path}")

def load_rng_state(round_id, save_dir="rng_states"):

    load_path = os.path.join(save_dir, f"rng_round_{round_id}.pt")

    rng_state = torch.load(load_path)

    random.setstate(rng_state["python"])
    np.random.set_state(rng_state["numpy"])
    torch.set_rng_state(rng_state["torch_cpu"])

    if torch.cuda.is_available() and rng_state["torch_cuda"] is not None:
        torch.cuda.set_rng_state_all(rng_state["torch_cuda"])

    print(f"[Loaded RNG] Round {round_id} <- {load_path}")



for iDataSet in range(nDataSet):
    #特征维度
    print('emb_size0:',emb_size)

    print('num_generation:',config['num_generation'] )
    #空间尺寸
    print('patch_size:',patch_size )
    #随机种子
    print('seeds:', seeds[iDataSet])
    # load target domain data for training and testing加载目标域数据进行训练和测试
    ##设置随机实验种子
    np.random.seed(seeds[iDataSet])

    #保存没有随机种子时的rng
    #save_rng_state(iDataSet)
    #print(f"Start Round {iDataSet}")
















                                            #-----------------------------------------------------修改后的内容-------------------------------------------------------------------------


    #从目标域完整图像中创建小样本学习所需的数据结构
    #将数据集中的内容传递给变量。train_loader训练集中的数据，test_loader测试集中的数据，target_da_metatrain_data按类别组织的字典，用于构建元学习任务，G:完整的分类地图（用于可视化）RandPerm:随机排列索引（数据划分方式）Row, Column:像素的行列坐标映射nTrain训练样本总数
    train_loader, test_loader, target_da_metatrain_data, G, RandPerm, Row, Column, nTrain, target_aug_data_ssl, target_aug_label_ssl= get_target_dataset(
                                                                                                                                Data_Band_Scaler=Data_Band_Scaler,
                                                                                                                                GroundTruth=GroundTruth,
                                                                                                                                class_num=TAR_CLASS_NUM,
                                                                                                                                tar_lsample_num_per_class=TAR_LSAMPLE_NUM_PER_CLASS,
                                                                                                                                shot_num_per_class=TAR_LSAMPLE_NUM_PER_CLASS,
                                                                                                                                patch_size=patch_size, test2=True)





    target_ssl_dataset = tagetSSLDataset(target_aug_data_ssl, target_aug_label_ssl)
    target_ssl_dataloader = torch.utils.data.DataLoader(target_ssl_dataset, batch_size=64, shuffle=True, drop_last=True)





                                                                #--------------------------------------------------------结束------------------------------------------






    # 将以下真实信息传入到变量num_supports...中
    # TAR_CLASS_NUM:目标类别数（如9）SHOT_NUM_PER_CLASS:每类支持集样本数（如1）QUERY_NUM_PER_CLASS:每类查询集样本数（如19）batch_task:批次中的任务数（如2）device:计算设备（cuda/cpu）
    num_supports, num_samples, query_edge_mask, evaluation_mask = utils.preprocess(TAR_CLASS_NUM, SHOT_NUM_PER_CLASS, QUERY_NUM_PER_CLASS, train_opt['batch_task'], GPU)
    support_tsne = train_loader


    #把“源域”小样本任务要用到的 DPGN 图网络实例化，并搬到 GPU 上等待训练/推理
    IDE_block_src = DPGN(config['num_generation'],
                      train_opt['dropout'],
                      TAR_CLASS_NUM * SHOT_NUM_PER_CLASS,
                      TAR_CLASS_NUM * SHOT_NUM_PER_CLASS + TAR_CLASS_NUM * QUERY_NUM_PER_CLASS,
                      config['point_distance_metric'],
                      config['distribution_distance_metric'],
                      emb_size).to(GPU)

    #把“目标域”小样本任务要用到的 DPGN 图网络实例化，并搬到 GPU 上等待训练/推理
    IDE_block_tar = DPGN(config['num_generation'],
                      train_opt['dropout'],
                      TAR_CLASS_NUM * SHOT_NUM_PER_CLASS,
                      TAR_CLASS_NUM * SHOT_NUM_PER_CLASS + TAR_CLASS_NUM * QUERY_NUM_PER_CLASS,
                      config['point_distance_metric'],
                      config['distribution_distance_metric'],
                      emb_size).to(GPU)


    #实例化一个“跨支持集注意力图网络”模块 CSA_block_att，并搬到 GPU 上，用来让源域和目标域的支持集特征互相做交叉注意力
    CSA_block_att = CSA_block.AttentionalGNN(num_supports, emb_size, ['cross']*config['num_generation']).to(GPU)
    #实例化一个用于把原始图像块（patch）映射成特征向量的“特征编码器”网络，输出维度为 emb_size，后续再交给元学习或图网络模块使用
    #给源域 DPGN 图网络分配一个 Adam 优化器，后续反向传播时各更新各的参数shizh
    IDE_block_src_optim = torch.optim.Adam(IDE_block_src.parameters(), lr=LEARNING_RATE, weight_decay=train_opt['weight_decay'])
    # 给目标域 DPGN 图网络分配一个 Adam 优化器，后续反向传播时各更新各的参数
    IDE_block_tar_optim = torch.optim.Adam(IDE_block_tar.parameters(), lr=LEARNING_RATE, weight_decay=train_opt['weight_decay'])
    # 给跨域注意力GNN分配一个 Adam 优化器，后续反向传播时各更新各的参数
    CCSA_block_att_optim = torch.optim.Adam(CSA_block_att.parameters(), lr=LEARNING_RATE, weight_decay=train_opt['weight_decay'])

    #模型初始化
    IDE_block_src.apply(weights_init)
    IDE_block_tar.apply(weights_init)
    CSA_block_att.apply(weights_init)

    # 为所有模型设置训练模式
    IDE_block_src.train()
    IDE_block_tar.train()
    CSA_block_att.train()
    # 记录训练开始
    print("Training...")
    # 初始化所有统计变量
    last_accuracy = 0.0
    last_accuracy_gnn = 0.0
    best_episdoe = 0
    train_loss = []


    # 模型初始化

    # 将源域与目标域图像的特征映射到统一特征空间中，以便后续跨域对齐。
    mapping_src = Mapping(SRC_INPUT_DIMENSION, N_DIMENSION).to(device)
    mapping_tar = Mapping(TAR_INPUT_DIMENSION, N_DIMENSION).to(device)
    mapping_tar_kuai = Mapping(32, N_DIMENSION).to(device)
    mapping_src_kuai = Mapping(32, N_DIMENSION).to(device)
    # 创建一个名为 encoder 的神经网络模型，并将其移动到指定的设备
    encoder = Encoder(n_dimension=N_DIMENSION, patch_size=patch_size, emb_size=emb_size).to(device)

    # 分别对源域映射层，目标域映射层，主编码器，目标域块映射和源域块映射设置SGD优化器，用于指导模型参数更新
    mapping_src_optim = torch.optim.SGD(mapping_src.parameters(), lr=LEARNING_RATE, momentum=0.9,
                                        weight_decay=WEIGHT_DECAY)
    mapping_tar_optim = torch.optim.SGD(mapping_tar.parameters(), lr=LEARNING_RATE, momentum=0.9,
                                        weight_decay=WEIGHT_DECAY)
    encoder_optim = torch.optim.SGD(encoder.parameters(), lr=LEARNING_RATE, momentum=0.9, weight_decay=WEIGHT_DECAY)
    mapping_tar_optim_kuai = torch.optim.SGD(mapping_tar_kuai.parameters(), lr=LEARNING_RATE, momentum=0.9,
                                             weight_decay=WEIGHT_DECAY)
    mapping_src_optim_kuai = torch.optim.SGD(mapping_src_kuai.parameters(), lr=LEARNING_RATE, momentum=0.9,
                                             weight_decay=WEIGHT_DECAY)

    # 参数初始化
    # 模型权重初始化，避免梯度小时或爆炸，提高训练的稳定性
    mapping_src.apply(utils.weights_init)
    mapping_tar.apply(utils.weights_init)
    encoder.apply(utils.weights_init)
    mapping_tar_kuai.apply(utils.weights_init)
    mapping_src_kuai.apply(utils.weights_init)
    # why? RuntimeError: Tensor for 'out' is on CPU, Tensor for argument #1 'self' is on CPU, but expected them to be on device (while checking arguments for addmm)
    # 将模型移动到指定的设备上
    mapping_src.to(device)
    mapping_tar.to(device)
    encoder.to(device)
    mapping_tar_kuai.to(device)
    mapping_src_kuai.to(device)
    # 为所有模型设置训练模式
    mapping_src.train()
    mapping_tar.train()
    mapping_tar_kuai.train()
    mapping_src_kuai.train()
    encoder.train()
    # 记录训练开始
    logger.info("Training...")
    # 初始化所有统计变量
    total_hit_src, total_num_src, total_hit_tar, total_num_tar, acc_src, acc_tar = 0.0, 0.0, 0.0, 0.05, 0.0, 0.0

    # 记录训练开始时间
    train_start = time.time()
    writer = SummaryWriter()
    data_embed_collect = []
    best_data_embed_collect = []
    # source_iter = iter(source_data_loader)【
    # 应该是定期评估目标域性能使用的


    train_start = time.time()
    for episode in range(EPISODE):

        # 这里是要改的地方（Gia的数据分割与MCMD的数据分割方式不一样）

        # get few-shot classification samples获取few-shot分类样本

        task_src = utils.Task(metatrain_data, TAR_CLASS_NUM, SHOT_NUM_PER_CLASS, QUERY_NUM_PER_CLASS)
        support_dataloader_src = utils.get_HBKC_data_loader(task_src, num_per_class=SHOT_NUM_PER_CLASS, split="train", shuffle=False)
        query_dataloader_src = utils.get_HBKC_data_loader(task_src, num_per_class=QUERY_NUM_PER_CLASS, split="test", shuffle=False)

        task_tar = utils.Task(target_da_metatrain_data, TAR_CLASS_NUM, SHOT_NUM_PER_CLASS, QUERY_NUM_PER_CLASS)
        support_dataloader_tar = utils.get_HBKC_data_loader(task_tar, num_per_class=SHOT_NUM_PER_CLASS, split="train", shuffle=False)
        query_dataloader_tar = utils.get_HBKC_data_loader(task_tar, num_per_class=QUERY_NUM_PER_CLASS, split="test", shuffle=False)

        # 获取源域支持集和查询集
        support_iter_src = iter(support_dataloader_src)
        #从源域支持集中取出一个batch(即一个 episode)，包含源域支持集数据和对应的标签
        supports_src, support_labels_src = next(support_iter_src)
        #print("supports_src的形为", supports_src.shape)
        query_iter_src = iter(query_dataloader_src)
        # 从源域查询集中取出一个batch(即一个 episode)，包含源域查询集数据和对应的标签
        querys_src, query_labels_src = next(query_iter_src)

        # 获取目标域支持集和查询集
        support_iter_tar = iter(support_dataloader_tar)
        #从目标域支持集中取出一个batch(即一个 episode)，包含目标域支持集数据和对应的标签
        supports_tar, support_labels_tar = next(support_iter_tar)

        query_iter_tar = iter(query_dataloader_tar)
        # 从目标域查询集中取出一个batch(即一个 episode)，包含目标域查询集数据和对应的标签
        querys_tar, query_labels_tar = next(query_iter_tar)

        # 上面到这里为止，所有东西一模一样，只是复制到gia中的话需要support_src中+s变成supports_src


        # 获取支持集中每个样本在原始数据集中的真实类别标签，而不是在当前小样本任务中重新编号的临时标签。
        support_real_labels_src = task_src.support_real_labels
        support_real_labels_tar = task_tar.support_real_labels


        # 从"文本特征仓库"中按需取货，快速配齐小样本学习情景所需的所有材料，避免在训练过程中实时进行特征提取的时间消耗
        # 源域空间文本特征
        w1_support_src = torch.zeros(TAR_CLASS_NUM, 768)
        for i, class_id in enumerate(support_real_labels_src):
            w1_support_src[i] = torch.from_numpy(outputs_w1_src[class_id])

        # 目标域空间文本特征
        w2_support_tar = torch.zeros(TAR_CLASS_NUM, 768)
        for i, class_id in enumerate(support_real_labels_tar):
            w2_support_tar[i] = torch.from_numpy(outputs_w2_src[class_id])

        # 源域光谱文本特征
        g1_support_src = torch.zeros(TAR_CLASS_NUM, 768)
        for i, class_id in enumerate(support_real_labels_src):
            g1_support_src[i] = torch.from_numpy(outputs_g1_src[class_id])

        # 目标域光谱文本特征
        g2_support_tar = torch.zeros(TAR_CLASS_NUM, 768)
        for i, class_id in enumerate(support_real_labels_tar):
            g2_support_tar[i] = torch.from_numpy(outputs_g2_src[class_id])


        # 计算loss使用的
        # 源域查询集多维分割
        q_new_s = split_tensor(querys_src)
        q_data_s = preprocess_data(querys_src, query_labels_src)
        q_new_s_k = split_tensor2(querys_src, SRC_INPUT_DIMENSION)
        # 目标域查询集的多维分割
        q_new_t = split_tensor(querys_tar)
        q_data_t = preprocess_data(querys_tar, query_labels_tar)
        q_new_t_k = split_tensor2(querys_tar, TAR_INPUT_DIMENSION)



        #功能：让MCMD中support_features_src的值拿过来，可以让Gia模型直接用（这里已经把MCMD中support_features_src的形[16,768]改成了Gia中upport_features_src的形[16,128]，通过修改Encoder代码实现的）

        # 让编码器同时处理源域的图像数据和语义特征，提取融合后的多模态特征表示，用于后续的小样本学习。
        # 仅使用了源域的已标注数据，没有使用目标域的
        # support_features_src是最终图像特征（源域已标注数据）的源域支持集，spatial_feature_src是源域支持集的空间特征，spectral_feature_src是源域支持集的光谱特征，semantic_feature_src是源域支持集的空间文本语义特征，semantic_feature2_src是源域支持集的光谱文本语义特征
        support_features_src_bushiliebiao, spatial_feature_src, spectral_feature_src,support_spectral_inter_src,support_spatial_inter_src, semantic_feature_src, semantic_feature2_src,AAA_src= encoder(
                                                                                                                                            mapping_src(supports_src.to(device)),  # 源域图像数据
                                                                                                                                            semantic_feature=w1_support_src.to(device),  # 源域空间文本特征
                                                                                                                                            semantic_feature2=g1_support_src.to(device),  # 源域光谱文本特征
                                                                                                                                            s_or_q="support")  # (9, 160)                   #标记为支持集
        # query_features_src是源域查询集的图像特征，spa_st包含源域查询集的空间特征，spe_st包含源域查询集的光谱特征（没有文本特征，因为查询集没有文本）
        query_features_src_bushiliebiao, spa_st, spe_st,query_spectral_inter_src,query_spatial_inter_src = encoder(mapping_src(querys_src.to(device)), f=True)  # (171, 160)

        # support_features_tar最终融合图像和文本的特征（目标域已标注数据）的目标域支持集，spatial_feature_tar是目标域支持集的空间特征，spectral_feature_tar是目标域支持集的光谱特征
        support_features_tar_bushiliebiao, spatial_feature_tar, spectral_feature_tar,support_spectral_inter_tar,support_spatial_inter_tar,  semantic_feature_tar, semantic_feature2_tar,AAA_tar= encoder(
                                                                                                                                            mapping_tar(supports_tar.to(device)),  # 目标域图像数据
                                                                                                                                            semantic_feature=w2_support_tar.to(device),  # 目标域空间文本特征
                                                                                                                                            semantic_feature2=g2_support_tar.to(device),  # 目标域光谱文本特征
                                                                                                                                            s_or_q="support")  # (9, 160)                   #标记为支持集
        # query_features_tar是目标域查询集的图像特征，spa_qt包含目标域查询集的空间特征，spe_qt包含目标域查询集的光谱特征（没有文本特征，因为查询集没有文本）
        query_features_tar_bushiliebiao, spa_qt, spe_qt,query_spectral_inter_tar,query_spatial_inter_tar = encoder(mapping_tar(querys_tar.to(device)), f=True)  # (171, 160)

        support_features_src = [None, None]  # 后续根据需要赋值

        flattened11 = support_spectral_inter_src.view(16, -1)
        support_spectral_inter_src = compress_layer11(flattened11)
        # print("feature time:", time.time() - start)
        # start = time.time()

        flattened1 = support_spatial_inter_src.view(16, -1)
        support_spatial_inter_src = compress_layer1(flattened1)

        support_features_src[0] = 0.5 * support_spectral_inter_src + 0.5 * support_spatial_inter_src  # [16,24,1,9,9]
        support_features_src[1] = support_features_src_bushiliebiao  # 赋值给第一个位置

        # 此时的support_features_src才是之前gia中support_features_src = feature_encoder(supports_src.to(GPU))的support_features_src变量的值

        # 同理，将query_features_src，support_features_tar，query_features_tar都和上面的support_features_src一样做一下变换。
        query_features_src = [None, None]  # 后续根据需要赋值

        flattened22 = query_spectral_inter_src.view(304, -1)
        query_spectral_inter_src = compress_layer22(flattened22)

        flattened2 = query_spatial_inter_src.view(304, -1)
        query_spatial_inter_src = compress_layer2(flattened2)

        query_features_src[0] = 0.5 * query_spectral_inter_src + 0.5 * query_spatial_inter_src
        query_features_src[1] = query_features_src_bushiliebiao  # 赋值给第一个位置

        support_features_tar = [None, None]  # 后续根据需要赋值

        flattened33 = support_spectral_inter_tar.view(16, -1)
        support_spectral_inter_tar = compress_layer33(flattened33)

        flattened3 = support_spatial_inter_tar.view(16, -1)
        support_spatial_inter_tar = compress_layer3(flattened3)

        support_features_tar[0] = 0.5 * support_spectral_inter_tar + 0.5 * support_spatial_inter_tar
        support_features_tar[1] = support_features_tar_bushiliebiao  # 赋值给第一个位置

        query_features_tar = [None, None]  # 后续根据需要赋值

        flattened44 = query_spectral_inter_tar.view(304, -1)
        query_spectral_inter_tar = compress_layer44(flattened44)

        flattened4 = query_spatial_inter_tar.view(304, -1)
        query_spatial_inter_tar = compress_layer4(flattened4)

        query_features_tar[0] = 0.5 * query_spectral_inter_tar + 0.5 * query_spatial_inter_tar
        query_features_tar[1] = query_features_tar_bushiliebiao  # 赋值给第一个位置


        # initialize nodes and edges for dual graph model为双图模型初始化节点和边
        #预存分配空间
        tensors_src = utils.allocate_tensors()



        for key, tensor in tensors_src.items():
            tensors_src[key] = tensor.to(GPU)

        #把四个变量（support_features_src中第二个数据，support_labels_src，query_features_src中第二个数据，query_labels_src）封装到一个batch——src中并修改维度适应initialize_nodes_edges的输入
        #先把support_features_src中第二个数据，support_labels_src，query_features_src中第二个数据，query_labels_src这四个变量的维度[1]变成模型要求的输入维度[1,1,1]
        batch_src = [support_features_src[1].unsqueeze(0).unsqueeze(0),support_labels_src.unsqueeze(0).unsqueeze(0),query_features_src[1].unsqueeze(0).unsqueeze(0),query_labels_src.unsqueeze(0).unsqueeze(0)]
        # 把四个变量（support_features_tar中第二个数据，support_labels_tar，query_features_tar中第二个数据，query_labels_tar）封装到一个batch——src中并修改维度适应initialize_nodes_edges的输入
        batch_tar = [support_features_tar[1].unsqueeze(0).unsqueeze(0),support_labels_tar.unsqueeze(0).unsqueeze(0),query_features_tar[1].unsqueeze(0).unsqueeze(0),query_labels_tar.unsqueeze(0).unsqueeze(0)]
        #initialize_nodes_edges函数的作用就是创建了分布图和点图
        support_data_src, support_label_src, query_data_src, query_label_src, all_data_src, all_label_in_edge_src, node_feature_gd_src,edge_feature_gp_src, edge_feature_gd_src = utils.initialize_nodes_edges(batch_src,
                                                                                                                                                                                                                num_supports,
                                                                                                                                                                                                                tensors_src,
                                                                                                                                                                                                                train_opt['batch_task'],
                                                                                                                                                                                                                query_labels_src.shape[0],
                                                                                                                                                                                                                TAR_CLASS_NUM,
                                                                                                                                                                                                                GPU)
        # 预存分配空间
        tensors_tar = utils.allocate_tensors()


        for key, tensor in tensors_tar.items():
            tensors_tar[key] = tensor.to(GPU)
        #原理同上，上面是改的源域数据，这里改的目标域数据
        support_data_tar, support_label_tar, query_data_tar, query_label_tar, all_data_tar, all_label_in_edge_tar, node_feature_gd_tar, \
        edge_feature_gp_tar, edge_feature_gd_tar = utils.initialize_nodes_edges(batch_tar,
                                                                    num_supports,
                                                                    tensors_tar,    
                                                                    train_opt['batch_task'],
                                                                    query_labels_tar.shape[0],
                                                                    TAR_CLASS_NUM,
                                                                    GPU)
        #print("support_features_src.shape",support_features_src[1].shape)       #[16, 128]
        #print("support_features_tar.shape",support_features_tar[1].shape)       #[16, 128]
        # calculate prototype
        #如果源域支持集（support_proto_src）或目标域支持集（support_proto_tar）中每类有多张图（SHOT_NUM_PER_CLASS > 1），则按类别聚合求平均，得到类别中心。如果每类只有一张图（SHOT_NUM_PER_CLASS = 1），则直接使用样本特征本身。
        if SHOT_NUM_PER_CLASS > 1:
            support_proto_src = [support_features_src[i].reshape(TAR_CLASS_NUM, SHOT_NUM_PER_CLASS, -1).mean(dim=1) for i in range(len(support_features_src))]
            support_proto_tar = [support_features_tar[i].reshape(TAR_CLASS_NUM, SHOT_NUM_PER_CLASS, -1).mean(dim=1) for i in range(len(support_features_tar))]
        else:
            support_proto_src = support_features_src
            support_proto_tar = support_features_tar
        #print("support_features_src.shape", support_features_src[1].shape)      #[16, 128]
        #print("support_features_tar.shape", support_features_tar[1].shape)      #[16, 128]


        """
        #原版
        
        # the IDE-block（特征拼接，不加 detach）
        second_last_layer_data_src = torch.cat((support_features_src[0], query_features_src[0]), dim=0).unsqueeze(0)
        last_layer_data_src = torch.cat((support_features_src[1], query_features_src[1]), dim=0).unsqueeze(0)

        second_last_layer_data_tar = torch.cat((support_features_tar[0], query_features_tar[0]), dim=0).unsqueeze(0)
        last_layer_data_tar = torch.cat((support_features_tar[1], query_features_tar[1]), dim=0).unsqueeze(0)


        # ⚠️ 保证 IDE_block 内部不要对输入 detach
        # 若你不确定，可以临时强制禁止 detach：
        with torch.enable_grad():
            _, _, _, point_nodes_src, distribution_nodes_src = IDE_block_src(
                second_last_layer_data_src,
                last_layer_data_src,
                node_feature_gd_src,
                edge_feature_gd_src,
                edge_feature_gp_src
            )

            _, _, _, point_nodes_tar, distribution_nodes_tar = IDE_block_tar(
                second_last_layer_data_tar,
                last_layer_data_tar,
                node_feature_gd_tar,
                edge_feature_gd_tar,
                edge_feature_gp_tar
            )
        """



























                                                        # ---------------------------------------------------新增分别对空间和光谱特征使用IDE_bLOCK模块，然后平均加权融合-------------------------------------------------------



        #光谱特征 the IDE-block
        second_last_layer_data_src_spe = torch.cat((support_spectral_inter_src, query_spectral_inter_src), dim=0).unsqueeze(0)
        last_layer_data_src_spe = torch.cat((spectral_feature_src, spe_st), dim=0).unsqueeze(0)
        second_last_layer_data_tar_spe = torch.cat((support_spectral_inter_tar, query_spectral_inter_tar), dim=0).unsqueeze(0)
        last_layer_data_tar_spe = torch.cat((spectral_feature_tar, spe_qt), dim=0).unsqueeze(0)

        # 空间特征 the IDE-block
        second_last_layer_data_src_spa = torch.cat((support_spatial_inter_src, query_spatial_inter_src),dim=0).unsqueeze(0)
        last_layer_data_src_spa = torch.cat((spatial_feature_src, spa_st), dim=0).unsqueeze(0)
        second_last_layer_data_tar_spa = torch.cat((support_spatial_inter_tar, query_spatial_inter_tar),dim=0).unsqueeze(0)
        last_layer_data_tar_spa = torch.cat((spatial_feature_tar, spa_qt), dim=0).unsqueeze(0)



        with torch.enable_grad():
            #空间spe
            _, _, _, point_nodes_src_spe, distribution_nodes_src_spe = IDE_block_src(
                second_last_layer_data_src_spe,
                last_layer_data_src_spe,
                node_feature_gd_src,
                edge_feature_gd_src,
                edge_feature_gp_src
            )

            _, _, _, point_nodes_tar_spe, distribution_nodes_tar_spe = IDE_block_tar(
                second_last_layer_data_tar_spe,
                last_layer_data_tar_spe,
                node_feature_gd_tar,
                edge_feature_gd_tar,
                edge_feature_gp_tar
            )

            #光谱spa
            _, _, _, point_nodes_src_spa, distribution_nodes_src_spa = IDE_block_src(
                second_last_layer_data_src_spa,
                last_layer_data_src_spa,
                node_feature_gd_src,
                edge_feature_gd_src,
                edge_feature_gp_src
            )

            _, _, _, point_nodes_tar_spa, distribution_nodes_tar_spa = IDE_block_tar(
                second_last_layer_data_tar_spa,
                last_layer_data_tar_spa,
                node_feature_gd_tar,
                edge_feature_gd_tar,
                edge_feature_gp_tar
            )











                                        #-------------------------------------------------------------结束-----------------------------------------------------





































        # 判断源域查询集与源域支持集的相似度，并打分，每个类别的分数存在logits_src变量中。
        logits_src = utils.euclidean_metric(query_features_src[1], support_proto_src[1])
        # 计算预测值与真实值之间的差距（看评分，哪个类别评分最高就意味着想选这个类型，再看真实标签是不是这个类型），以此来指导模型调整参数提升效果。
        # 模型通过源域支持集训练，用源域查询集测试，将在源域查询集上的测试结果与源域查询集本身的真实标签对比，然后打分
        f_loss_src = crossEntropy(logits_src, query_labels_src.long().to(device))


        # 判断目标域查询集的图像特征与目标域支持集的图像特征，并打分，每个类别的分数存在logits_tar变量中。
        logits_tar = utils.euclidean_metric(query_features_tar[1], support_proto_tar[1])
        # 计算预测值与真实值之间的差距（看评分，哪个类别评分最高就意味着想选这个类型，再看真实标签是不是这个类型），以此来指导模型调整参数提升效果。
        # 模型通过目标域支持集训练，用目标域查询集测试，将在目标域查询集上的测试结果与目标域查询集本身的真实标签对比，然后打分
        f_loss_tar = crossEntropy(logits_tar, query_labels_tar.long().to(device))
        # 整体分数等于源域上打的分和目标域上打的分相加。
        f_loss = f_loss_src + f_loss_tar

                                                            #------------------------------------------------------新增的中间层原型对齐--------------------------------------------

        # 判断源域查询集与源域支持集的相似度，并打分，每个类别的分数存在logits_src变量中。
        logits_src1 = utils.euclidean_metric(query_features_src[0], support_proto_src[0])
        # 计算预测值与真实值之间的差距（看评分，哪个类别评分最高就意味着想选这个类型，再看真实标签是不是这个类型），以此来指导模型调整参数提升效果。
        # 模型通过源域支持集训练，用源域查询集测试，将在源域查询集上的测试结果与源域查询集本身的真实标签对比，然后打分
        f_loss_src1 = crossEntropy(logits_src1, query_labels_src.long().to(device))

        # 判断目标域查询集的图像特征与目标域支持集的图像特征，并打分，每个类别的分数存在logits_tar变量中。
        logits_tar1 = utils.euclidean_metric(query_features_tar[0], support_proto_tar[0])
        # 计算预测值与真实值之间的差距（看评分，哪个类别评分最高就意味着想选这个类型，再看真实标签是不是这个类型），以此来指导模型调整参数提升效果。
        # 模型通过目标域支持集训练，用目标域查询集测试，将在目标域查询集上的测试结果与目标域查询集本身的真实标签对比，然后打分
        f_loss_tar1 = crossEntropy(logits_tar1, query_labels_tar.long().to(device))
        # 整体分数等于源域上打的分和目标域上打的分相加。
        f_loss1 = f_loss_src1 + f_loss_tar1
                                                                #--------------------MCMD中没有使用的代码+新增的代码----------------------------------


        # 判断源域查询集的空间特征与源域支持集的空间特征，并打分，每个类别的分数存在logits_src_spa变量中。
        logits_src_spa = utils.euclidean_metric(spa_st, spatial_feature_src)
        # 判断源域查询集的光谱特征与源域支持集的光谱特征，并打分，每个类别的分数存在logits_src_spe变量中。
        logits_src_spe = utils.euclidean_metric(spe_st, spectral_feature_src)
        # 判断目标域查询集的空间特征与目标域支持集的空间特征，并打分，每个类别的分数存在logits_tar_spa变量中。
        logits_tar_spa = utils.euclidean_metric(spa_qt, spatial_feature_tar)
        # 判断目标域查询集的光谱特征与目标域支持集的光谱特征，并打分，每个类别的分数存在logits_tar_spe变量中。
        logits_tar_spe = utils.euclidean_metric(spe_qt, spectral_feature_tar)

        # ========== 空间 / 光谱一致性蒸馏损失 ==========


        

        spa_loss_src = crossEntropy(logits_src_spa, query_labels_src.long().to(device))


        spe_loss_src = crossEntropy(logits_src_spe, query_labels_src.long().to(device))


        spa_loss_tar = crossEntropy(logits_tar_spa, query_labels_tar.long().to(device))


        spe_loss_tar = crossEntropy(logits_tar_spe, query_labels_tar.long().to(device))


                                                                #-----------------------------------------------------结束-----------------------------------------------


        # 多模态原型校正层(MC)使用BERT 提取的文本语义向量对图像原型进行语义校正，前面对文本做了各种处理，现在到了需要用的时候了
        # 空间特征和空间文本特征对齐
        text_align_loss_src = infoNCE_Loss(spatial_feature_src, semantic_feature_src) + infoNCE_Loss(
            spectral_feature_src, semantic_feature2_src)
        # 光谱特征和光谱文本特征对齐
        text_align_loss_tar = infoNCE_Loss(spatial_feature_tar, semantic_feature_tar) + infoNCE_Loss(
            spectral_feature_tar, semantic_feature2_tar)













        
                                            #--------------------------------新增----------------------------------------


        
        SupConLoss_t = SupConLoss(temperature=0.01).to(GPU)

        target_ssl_iter = iter(target_ssl_dataloader)

        # target domain supervised contrastive learning
        try:
            target_ssl_data, target_ssl_label = next(target_ssl_iter)
        except Exception as err:
            target_ssl_iter = iter(target_ssl_dataloader)
            target_ssl_data, target_ssl_label = next(target_ssl_iter)

        augment1_target_ssl_data = torch.FloatTensor(
            data_augment.random_mask_batch_image(target_ssl_data.data.cpu(), 0.8))  # (128, 200, 7, 7)
        augment2_target_ssl_data = torch.FloatTensor(
            data_augment.random_mask_batch_image(target_ssl_data.data.cpu(), 0.8))  # (128, 200, 7, 7)
        augment_target_ssl_data = torch.cat((augment1_target_ssl_data, augment2_target_ssl_data),
                                            dim=0)  # (256, 200, 7, 7)

        features_augment = encoder(mapping_tar(augment_target_ssl_data.to(GPU)))  # (256, 128)

        augment1_target_ssl_feature = F.normalize(features_augment[:len(target_ssl_data), :], dim=1)  # (128, 128)
        augment2_target_ssl_feature = F.normalize(features_augment[len(target_ssl_data):, :], dim=1)  # (128, 128)
        augment_target_ssl_feature = torch.cat(
            [augment1_target_ssl_feature.unsqueeze(1), augment2_target_ssl_feature.unsqueeze(1)],
            dim=1)  # (128, 2, 128)
        scl_loss_tar = SupConLoss_t(augment_target_ssl_feature, target_ssl_label)



                                        #-------------------------------------------------结束--------------------------------------------






























                                                            #------------------------------------------------------------结束----------------------------------------------------------------

        # 将所有损失进行汇总。f_loss计算模型对分类的预测值与真实值之间的差距。text_align_loss_src空间特征和空间文本特征对齐，text_align_loss_tar光谱特征和光谱文本特征对齐，z_loss_t目标域空间维度数据中的总损失函数，z_loss_t_k目标域光谱维度数据中的总损失函数，z_loss_s源域空间维度数据中的总损失函数，z_loss_s_k源域光谱维度数据中的总损失函数，support_align_loss支持集中间层损失，query_align_loss查询集中间层损失
        #方法十（2*是方法十），效果最好

        # 方法十一
        #loss1 = f_loss + 2 * (text_align_loss_src + text_align_loss_tar) + f_loss1 + 2 * (spa_loss_src + spe_loss_src + spa_loss_tar + spe_loss_tar)
        #方法九
        #loss1 = f_loss + 2 * (text_align_loss_src + text_align_loss_tar) + f_loss1 + (spa_loss_src + spe_loss_src + spa_loss_tar + spe_loss_tar)



        #对齐中间层特征,不进行空间和光谱特征对齐
        #loss1 = f_loss + 2 * (text_align_loss_src + text_align_loss_tar) + spa_loss_src + spe_loss_src + spa_loss_tar + spe_loss_tar + f_loss1

        #对齐中间层原型特征（方法八现在最好的方法）
        #loss1 = f_loss + 2 * (text_align_loss_src + text_align_loss_tar)  + f_loss1




        """
        #原版
        # ⚠️ 确保 CSA_block_att 不含 .detach()/.data
        cross_att_loss = CSA_block_att(point_nodes_src, point_nodes_tar,distribution_nodes_src, distribution_nodes_tar)

        # === Domain alignment ===
        # ⚠️ 检查 utils.OT 内部是否 detach；如需保持可微，这里加 retain_graph=True 方便调试
        ot_ep, wd_ep, gwd_ep = utils.OT(point_nodes_src, point_nodes_tar)
        ot_ed, wd_ed, gwd_ed = utils.OT(distribution_nodes_src, distribution_nodes_tar)

        domain_loss = ot_ep + ot_ed
        """





















                                                    #----------------------------------新增分别对空间和光谱特征使用IDE_bLOCK模块，然后平均加权融合-----------------------------------------

        # ⚠️ 确保 CSA_block_att 不含 .detach()/.data
        # 空间spe
        cross_att_spe_loss = CSA_block_att(point_nodes_src_spe, point_nodes_tar_spe, distribution_nodes_src_spe,
                                           distribution_nodes_tar_spe)
        # 光谱spa
        cross_att_spa_loss = CSA_block_att(point_nodes_src_spa, point_nodes_tar_spa, distribution_nodes_src_spa,
                                           distribution_nodes_tar_spa)
        # 加权平均
        cross_att_loss = 0.5 * cross_att_spe_loss + 0.5 * cross_att_spa_loss

        # === Domain alignment ===
        # ⚠️ 检查 utils.OT 内部是否 detach；如需保持可微，这里加 retain_graph=True 方便调试
        # 空间spe
        ot_ep_spe, wd_ep_spe, gwd_ep_spe = utils.OT(point_nodes_src_spe, point_nodes_tar_spe)
        # 光谱spa
        ot_ep_spa, wd_ep_spa, gwd_ep_spa = utils.OT(point_nodes_src_spa, point_nodes_tar_spa)

        # 加权平均
        ot_ep = 0.5 * ot_ep_spe + 0.5 * ot_ep_spa

        # 空间spe
        ot_ed_spe, wd_ed_spe, gwd_ed_spe = utils.OT(distribution_nodes_src_spe, distribution_nodes_tar_spe)
        # 光谱spa
        ot_ed_spa, wd_ed_spa, gwd_ed_spa = utils.OT(distribution_nodes_src_spa, distribution_nodes_tar_spa)

        # 加权平均
        ot_ed = 0.5 * ot_ed_spe + 0.5 * ot_ed_spa

        # 汇总
        domain_loss = ot_ep + ot_ed

        wd_ep = 0.5 * wd_ep_spe + 0.5 * wd_ep_spa
        wd_ed = 0.5 * wd_ed_spe + 0.5 * wd_ed_spa
        gwd_ed = 0.5 * gwd_ed_spe + 0.5 * gwd_ed_spa
        gwd_ep = 0.5 * gwd_ep_spe + 0.5 * gwd_ep_spa
                                                    #------------------------------------------------结束---------------------------------------------------



        loss1 = f_loss + 2 * (text_align_loss_src + text_align_loss_tar) + f_loss1 + 2 * scl_loss_tar + 2 * (spa_loss_src + spe_loss_src + spa_loss_tar + spe_loss_tar)

        # === 总损失 ===
        #loss = loss1+ lambda_1 * domain_loss + lambda_2 * cross_att_loss

        loss =f_loss + f_loss1  + 2 * (text_align_loss_src + text_align_loss_tar) + 2 * (spa_loss_src + spe_loss_src + spa_loss_tar + spe_loss_tar) + lambda_1 * domain_loss + lambda_2 * cross_att_loss + 2 * scl_loss_tar

        # === 反向传播 ===
        #feature_encoder_optim.zero_grad()
        IDE_block_src_optim.zero_grad()
        IDE_block_tar_optim.zero_grad()
        CCSA_block_att_optim.zero_grad()
        mapping_src.zero_grad()
        mapping_tar.zero_grad()
        encoder.zero_grad()

        loss.backward(retain_graph=False)

        # === 更新参数 ===
        #feature_encoder_optim.step()
        IDE_block_src_optim.step()
        IDE_block_tar_optim.step()
        CCSA_block_att_optim.step()
        mapping_src_optim.step()
        mapping_tar_optim.step()
        encoder_optim.step()

        # === 训练准确率统计 ===
        total_hit_src += torch.sum(torch.argmax(logits_src, dim=1).cpu() == query_labels_src).item()
        total_num_src += querys_src.shape[0]
        total_hit_tar += torch.sum(torch.argmax(logits_tar, dim=1).cpu() == query_labels_tar).item()
        total_num_tar += querys_tar.shape[0]

        if (episode + 1) % 100 == 0:
            grad_norm = 0
            for name, p in encoder.named_parameters():
                if p.grad is not None:
                    grad_norm += p.grad.data.norm(2).item()
            print(f"[GradCheck] Encoder grad norm: {grad_norm:.6f}")


            train_loss.append(loss.item())
            # 获取当前时间并格式化
            current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S,%f')[:-3]


            #原版
            print(
                '[{0}] episode {1:>3d}:  domain loss: {2:6.4f}, fsl loss: {3:6.4f}, cross att loss: {4:6.4f}, acc_src {5:6.4f}, acc_tar {6:6.4f}, loss: {7:6.4f}'.format(
                    current_time,  # 新增时间戳参数
                    episode + 1,
                    domain_loss.item(),
                    f_loss.item(),
                    cross_att_loss.item(),
                    total_hit_src / total_num_src,
                    total_hit_tar / total_num_tar,
                    loss.item()
                ))
            """
            print(
                '[{0}] episode {1:>3d}:  fsl loss: {2:6.4f}, acc_src {3:6.4f}, acc_tar {4:6.4f}, loss: {5:6.4f}'.format(
                    current_time,  # 新增时间戳参数
                    episode + 1,
                    f_loss.item(),
                    total_hit_src / total_num_src,
                    total_hit_tar / total_num_tar,
                    loss.item()
                ))
            """
            print('wd {:6.6f}, gwd: {:6.6f}'.format((wd_ed + wd_ep).item(), (gwd_ed + gwd_ep).item()))
            print('fea_lr： {:6.6f}'.format(encoder_optim.param_groups[0]['lr']))

        if (episode + 1) % 500 == 0 or episode == 0:
            # test
            print("Testing ...")
            train_end = time.time()
            # 设置模型为评估模式
            mapping_tar.eval()
            #feature_encoder.eval()
            encoder.eval()
            total_rewards = 0
            counter = 0
            accuracies = []
            predict = np.array([], dtype=np.int64)
            predict_gnn = np.array([], dtype=np.int64)
            labels = np.array([], dtype=np.int64)

            # 获取数据迭代器
            train_iter = train_loader.__iter__()
            train_datas, train_labels,index = next(train_iter)

            # 直接将 Tensor 送到 GPU 并喂进模型
            train_features = encoder(mapping_tar(Variable(train_datas.float()).to(device)))
            max_value = train_features.max()
            min_value = train_features.min() 
            print(max_value.item())
            print(min_value.item())
            train_features = (train_features - min_value) * 1.0 / (max_value - min_value)

            KNN_classifier = KNeighborsClassifier(n_neighbors=1)
            KNN_classifier.fit(train_features.cpu().detach().numpy(), train_labels)
            test_labels_all, feature_emb= [], []
            for test_datas, test_labels,test_index  in test_loader:
                batch_size = test_labels.shape[0]

                test_features = encoder(mapping_tar((Variable(test_datas.float()).to(device))))
                feature_emb.append(test_features.cpu().detach().numpy())
                test_features = (test_features - min_value) * 1.0 / (max_value - min_value)
                predict_labels = KNN_classifier.predict(test_features.cpu().detach().numpy())

                test_labels = test_labels.numpy()
                test_labels_all.append(test_labels)
                rewards = [1 if predict_labels[j] == test_labels[j] else 0 for j in range(batch_size)]

                total_rewards += np.sum(rewards)
                counter += batch_size

                predict = np.append(predict, predict_labels)
                labels = np.append(labels, test_labels)

                accuracy = total_rewards / 1.0 / counter  #
                accuracies.append(accuracy)

            test_accuracy = 100. * total_rewards / len(test_loader.dataset)

            print('\t\tAccuracy: {}/{} ({:.2f}%)\n'.format( total_rewards, len(test_loader.dataset),
                100. * total_rewards / len(test_loader.dataset)))
            print('seeds:', seeds[iDataSet])
            test_end = time.time()

            # 将模型评估模型切换为训练模式
            mapping_tar.train()
            #feature_encoder.train()
            mapping_tar.train()
            encoder.train()
            if test_accuracy > last_accuracy:
                last_accuracy = test_accuracy
                best_episdoe = episode

                acc[iDataSet] = 100. * total_rewards / len(test_loader.dataset)
                OA = acc
                C = metrics.confusion_matrix(labels, predict)
                A[iDataSet, :] = np.diag(C) / np.sum(C, 1, dtype=np.float)
                best_predict_all = predict
                best_G,best_RandPerm,best_Row, best_Column,best_nTrain = G, RandPerm, Row, Column, nTrain
                k[iDataSet] = metrics.cohen_kappa_score(labels, predict)

                feature_emb_end = np.concatenate(feature_emb)
                test_labels_end = np.concatenate(test_labels_all)

            print('best episode:[{}], best accuracy={}'.format(best_episdoe + 1, last_accuracy))

    print('iter:{} best episode:[{}], best accuracy={}'.format(iDataSet, best_episdoe + 1, last_accuracy))
    print('iter:{} best episode:[{}], best accuracy_gnn={}'.format(iDataSet, best_episdoe + 1, last_accuracy_gnn))
    print ("train time per DataSet(s): " + "{:.5f}".format(train_end-train_start))
    print("accuracy list: ", acc)
    print('***********************************************************************************')
    for i in range(len(best_predict_all)):
        best_G[best_Row[best_RandPerm[best_nTrain + i]]][best_Column[best_RandPerm[best_nTrain + i]]] = best_predict_all[i] + 1
    class_map[iDataSet] = best_G[4:-4, 4:-4]
    time_list[iDataSet] = train_end-train_start
    feature_emb_cell[iDataSet] = feature_emb_end
    test_labels_cell[iDataSet] = test_labels_end

AA = np.mean(A, 1)

AAMean = np.mean(AA,0)
AAStd = np.std(AA)

AMean = np.mean(A, 0)
AStd = np.std(A, 0)

OAMean = np.mean(acc)
OAStd = np.std(acc)

kMean = np.mean(k)
kStd = np.std(k)
print ("train time per DataSet(s): " + "{:.5f}".format(train_end-train_start))      #同上
print("test time per DataSet(s): " + "{:.5f}".format(test_end-train_end))
print("accuracy list: ", acc)                                                       #同上
print ("average OA: " + "{:.2f}".format( OAMean) + " +- " + "{:.2f}".format( OAStd))
print ("average AA: " + "{:.2f}".format(100 * AAMean) + " +- " + "{:.2f}".format(100 * AAStd))
print ("average kappa: " + "{:.4f}".format(100 *kMean) + " +- " + "{:.4f}".format(100 *kStd))
print ("accuracy for each class: ")
for i in range(TAR_CLASS_NUM):
    print ("Class " + str(i) + ": " + "{:.2f}".format(100 * AMean[i]) + " +- " + "{:.2f}".format(100 * AStd[i]))


best_iDataset = 0
for i in range(len(acc)):
    print('{}:{}'.format(i, acc[i]))
    if acc[i] > acc[best_iDataset]:
        best_iDataset = i
print('best acc all={}'.format(acc[best_iDataset]))