
import torch
import torch.nn as nn
import torch.nn.functional as F



import torch
import torch.nn as nn

class SpectralEncoder(nn.Module):
    def __init__(self, input_channels, patch_size, feature_dim):
        super(SpectralEncoder, self).__init__()
        self.input_channels = input_channels
        self.patch_size = patch_size
        self.feature_dim = feature_dim
        self.inter_size = 24

        self.conv1 = nn.Conv3d(
            1, self.inter_size,
            kernel_size=(7, 1, 1),
            stride=(2, 1, 1),
            padding=(1, 0, 0),
            bias=True
        )
        self.bn1 = nn.BatchNorm3d(self.inter_size)
        self.activation1 = nn.ReLU()

        self.conv2 = nn.Conv3d(
            self.inter_size, self.inter_size,
            kernel_size=(7, 1, 1),
            stride=(1, 1, 1),
            padding=(3, 0, 0),
            bias=True
        )
        self.bn2 = nn.BatchNorm3d(self.inter_size)
        self.activation2 = nn.ReLU()

        self.conv3 = nn.Conv3d(
            self.inter_size, self.inter_size,
            kernel_size=(7, 1, 1),
            stride=(1, 1, 1),
            padding=(3, 0, 0),
            bias=True
        )
        self.bn3 = nn.BatchNorm3d(self.inter_size)
        self.activation3 = nn.ReLU()

        self.conv4 = nn.Conv3d(
            self.inter_size, self.feature_dim,
            kernel_size=(((self.input_channels - 7 + 2 * 1) // 2 + 1), 1, 1),
            bias=True
        )
        self.bn4 = nn.BatchNorm3d(self.feature_dim)
        self.activation4 = nn.ReLU()

        self.avgpool = nn.AvgPool3d((1, self.patch_size, self.patch_size))
        self.avgpool2 = nn.AvgPool3d((1, 5, 5))

        # ===== 新增：光谱通道重标定（不改 shape）=====
        self.spectral_gate = nn.Sequential(
            nn.AdaptiveAvgPool3d((1, 1, 1)),  # (B, C, 1, 1, 1)
            nn.Conv3d(self.inter_size, self.inter_size, kernel_size=1, bias=False),
            nn.Sigmoid()
        )

        self.bn_spectral = nn.BatchNorm3d(self.inter_size)

    def forward(self, x, z=False):
        x = x.unsqueeze(1)

        x1 = self.activation1(self.bn1(self.conv1(x)))

        residual = x1

        x1 = self.activation2(self.bn2(self.conv2(x1)))

        # ===== 中间光谱特征（定义位置不变）=====
        x_spectral_inter = x1.clone()
        x_spectral_inter = self.bn_spectral(x_spectral_inter)

        # ===== 新增：光谱通道调制（结构创新）=====
        gate = self.spectral_gate(x1)
        x1 = x1 * gate

        x1 = self.conv3(x1)
        x1 = residual + x1
        x1 = self.activation3(self.bn3(x1))

        x1 = self.activation4(self.bn4(self.conv4(x1)))

        x1 = x1.reshape(x1.size(0), x1.size(1), x1.size(3), x1.size(4))

        if z:
            x1 = self.avgpool2(x1)
        else:
            x1 = self.avgpool(x1)

        x1 = x1.reshape((x1.size(0), -1))

        return x1, x_spectral_inter

class SpatialEncoder(nn.Module):
    def __init__(self, input_channels, patch_size, feature_dim):
        super(SpatialEncoder, self).__init__()
        self.input_channels = input_channels
        self.patch_size = patch_size
        self.feature_dim = feature_dim
        self.inter_size = 24

        self.conv5 = nn.Conv3d(1, self.inter_size, kernel_size=(self.input_channels, 1, 1))
        self.bn5 = nn.BatchNorm3d(self.inter_size)
        self.activation5 = nn.ReLU()

        self.conv8 = nn.Conv3d(self.inter_size, self.inter_size, kernel_size=(1, 1, 1))

        self.conv6 = nn.Conv3d(
            self.inter_size, self.inter_size,
            kernel_size=(1, 3, 3),
            padding=(0, 1, 1),
            bias=True
        )
        self.bn6 = nn.BatchNorm3d(self.inter_size)
        self.activation6 = nn.ReLU()

        self.conv7 = nn.Conv3d(
            self.inter_size, self.inter_size,
            kernel_size=(1, 3, 3),
            padding=(0, 1, 1),
            bias=True
        )
        self.bn7 = nn.BatchNorm3d(self.inter_size)
        self.activation7 = nn.ReLU()

        self.avgpool = nn.AvgPool3d((1, self.patch_size, self.patch_size))
        self.avgpool2 = nn.AvgPool3d((1, 5, 5))

        self.fc = nn.Sequential(
            nn.Dropout(p=0.5),
            nn.Linear(self.inter_size, self.feature_dim)
        )

        self.bn_wenli = nn.BatchNorm3d(self.inter_size)

        # ===== 新增：纹理感知空间门控 =====
        self.texture_gate = nn.Sequential(
            nn.AdaptiveAvgPool3d((1, 1, 1)),
            nn.Conv3d(self.inter_size, self.inter_size, kernel_size=1, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x, z=False):
        x = x.unsqueeze(1)

        x2 = self.activation5(self.bn5(self.conv5(x)))

        residual = self.conv8(x2)

        x2 = self.activation6(self.bn6(self.conv6(x2)))

        # ===== 中间纹理特征（定义位置不变）=====
        x_wenli = x2.clone()
        x_wenli = self.bn_wenli(x_wenli)

        # ===== 新增：纹理感知门控（结构创新）=====
        gate = self.texture_gate(x2)
        x2 = x2 * gate

        x2 = self.conv7(x2)
        x2 = residual + x2
        x2 = self.activation7(self.bn7(x2))

        x2 = x2.reshape(x2.size(0), x2.size(1), x2.size(3), x2.size(4))

        if z:
            x2 = self.avgpool2(x2)
        else:
            x2 = self.avgpool(x2)

        x2 = x2.reshape((x2.size(0), -1))
        x2 = self.fc(x2)

        return x2, x_wenli




class WordEmbTransformers(nn.Module):
    def __init__(self, feature_dim):
        super(WordEmbTransformers, self).__init__()
        self.feature_dim = feature_dim
        self.fc = nn.Sequential(nn.Linear(in_features=768,out_features=128,bias=True),nn.ReLU(),nn.Dropout(p=0.5),nn.Linear(in_features=128,out_features=self.feature_dim,bias=True))

    def forward(self, x):
        # 0-1
        x = self.fc(x)
        return x

class AdaptiveFusion(nn.Module):
    def __init__(self, feature_dim):
        super(AdaptiveFusion, self).__init__()
        self.fc = nn.Sequential(
            nn.Linear(feature_dim * 2, feature_dim),
            nn.ReLU(),
            nn.Linear(feature_dim, 2),
            nn.Softmax(dim=1)  # [w_spatial, w_spectral]
        )

    def forward(self, spatial_feat, spectral_feat):
        fusion_input = torch.cat([spatial_feat, spectral_feat], dim=1)
        weights = self.fc(fusion_input)  # (B, 2)

        fused = (
            weights[:, 0:1] * spatial_feat +
            weights[:, 1:2] * spectral_feat
        )
        return fused, weights

#文本引导融合模块
class TextGuidedAdaptiveFusion(nn.Module):
    def __init__(self, feature_dim, text_dim):
        super(TextGuidedAdaptiveFusion, self).__init__()

        # === 图像驱动的融合权重（视觉证据） ===
        self.image_fc = nn.Sequential(
            nn.Linear(feature_dim * 2, feature_dim),
            nn.ReLU(),
            nn.Linear(feature_dim, 2)
        )

        # === 文本驱动的融合先验（语义先验） ===
        self.text_fc = nn.Sequential(
            nn.Linear(text_dim * 2, feature_dim),
            nn.ReLU(),
            nn.Linear(feature_dim, 2)
        )

        self.softmax = nn.Softmax(dim=1)

    def forward(self,
                spatial_feat,
                spectral_feat,
                spatial_text_feat,
                spectral_text_feat,
                alpha=0.7):

        img_input = torch.cat([spatial_feat, spectral_feat], dim=1)
        w_img = self.softmax(self.image_fc(img_input))  # (B, 2)

        txt_input = torch.cat([spatial_text_feat, spectral_text_feat], dim=1)
        w_txt = self.softmax(self.text_fc(txt_input))  # (B, 2)

        fusion_weights = alpha * w_img + (1 - alpha) * w_txt

        fused_feature = (fusion_weights[:, 0:1] * spatial_feat +fusion_weights[:, 1:2] * spectral_feat)

        return fused_feature, fusion_weights, w_img, w_txt



class Encoder(nn.Module):
    def __init__(self, n_dimension, patch_size, emb_size):
        super(Encoder, self).__init__()

        self.n_dimension = n_dimension
        self.patch_size = patch_size
        self.emb_size = emb_size

        self.spectral_encoder = SpectralEncoder(input_channels=self.n_dimension,patch_size=self.patch_size,feature_dim=128)

        self.spatial_encoder = SpatialEncoder(input_channels=self.n_dimension,patch_size=self.patch_size,feature_dim=128)

        self.word_emb_transformers = WordEmbTransformers(feature_dim=self.emb_size)

        self.fusion = TextGuidedAdaptiveFusion(feature_dim=128,text_dim=self.emb_size)

    def forward(self,x,semantic_feature="",semantic_feature2="",s_or_q="query",z=False,f=False,alpha=0.7):

        spatial_feature, x_wenli = self.spatial_encoder(x, z)
        spectral_feature, spectral_inter = self.spectral_encoder(x, z)

        if f:
            spatial_spectral_fusion_feature = (0.5 * spatial_feature + 0.5 * spectral_feature)
            return (spatial_spectral_fusion_feature,spatial_feature,spectral_feature,spectral_inter,x_wenli)

        if s_or_q == "query":
            spatial_spectral_fusion_feature = (0.5 * spatial_feature + 0.5 * spectral_feature)
            return spatial_spectral_fusion_feature

        if s_or_q == "support":
            semantic_feature = self.word_emb_transformers(semantic_feature)
            semantic_feature2 = self.word_emb_transformers(semantic_feature2)

            spatial_spectral_fusion_feature, fusion_weights, w_img, w_txt = self.fusion(spatial_feature,spectral_feature,semantic_feature,semantic_feature2,alpha=alpha)

            return (spatial_spectral_fusion_feature,spatial_feature,spectral_feature,spectral_inter,x_wenli,semantic_feature,semantic_feature2,fusion_weights)

        spatial_spectral_fusion_feature = (0.5 * spatial_feature + 0.5 * spectral_feature)

        return spatial_spectral_fusion_feature