import torch
import torch.nn as nn
import torch.nn.functional as F
from copy import deepcopy


# ==============================
# 可训练特征标准化（小样本稳定版）
# ==============================
def normalize_feature(x, eps=1e-6):
    mean = x.mean(dim=-1, keepdim=True)
    std = x.std(dim=-1, keepdim=True)
    return (x - mean) / (std + eps)


# ==============================
# MLP
# ==============================
def MLP(channels: list, do_bn=True):
    n = len(channels)
    layers = []
    for i in range(1, n):
        layers.append(
            nn.Conv1d(channels[i - 1], channels[i], kernel_size=1, bias=True)
        )
        if i < (n - 1):
            if do_bn:
                layers.append(nn.BatchNorm1d(channels[i]))
            layers.append(nn.ReLU(inplace=True))
    return nn.Sequential(*layers)


# ==============================
# Attention
# ==============================
def attention(query, key, value):
    dim = query.shape[1]
    scores = torch.einsum('bdhn,bdhm->bhnm', query, key) / dim**0.5
    prob = F.softmax(scores, dim=-1)
    return torch.einsum('bhnm,bdhm->bdhn', prob, value), prob


# ==============================
# 稳定RBF MMD（小样本鲁棒版）
# ==============================
class MMD_loss(nn.Module):
    def __init__(self, kernel_mul=2.0, kernel_num=5):
        super(MMD_loss, self).__init__()
        self.kernel_mul = kernel_mul
        self.kernel_num = kernel_num

    def gaussian_kernel(self, source, target):
        n_samples = source.size(0) + target.size(0)
        total = torch.cat([source, target], dim=0)

        total0 = total.unsqueeze(0)
        total1 = total.unsqueeze(1)
        L2_distance = ((total0 - total1) ** 2).sum(2)

        bandwidth = torch.sum(L2_distance.detach()) / (n_samples**2 - n_samples + 1)
        bandwidth = bandwidth / (self.kernel_mul ** (self.kernel_num // 2))

        bandwidth_list = [bandwidth * (self.kernel_mul**i) for i in range(self.kernel_num)]
        kernel_val = [torch.exp(-L2_distance / (bw + 1e-8)) for bw in bandwidth_list]

        return sum(kernel_val)

    def forward(self, source, target):
        batch_size = source.size(0)
        kernels = self.gaussian_kernel(source, target)

        XX = kernels[:batch_size, :batch_size].mean()
        YY = kernels[batch_size:, batch_size:].mean()
        XY = kernels[:batch_size, batch_size:].mean()
        YX = kernels[batch_size:, :batch_size].mean()

        return XX + YY - XY - YX


# ==============================
# 稳定MultiHeadAttention（无接口变化版）
# ==============================
class MultiHeadedAttention(nn.Module):
    def __init__(self, num_heads: int, d_model: int):
        super().__init__()
        assert d_model % num_heads == 0

        self.dim = d_model // num_heads
        self.num_heads = num_heads

        self.merge = nn.Conv1d(d_model, d_model, kernel_size=1)
        self.proj = nn.ModuleList([deepcopy(self.merge) for _ in range(3)])

        self.norm = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(0.1)

    def forward(self, query, key, value):
        batch_dim = query.size(0)

        q, k, v = [
            l(x).view(batch_dim, self.dim, self.num_heads, -1)
            for l, x in zip(self.proj, (query, key, value))
        ]

        x, _ = attention(q, k, v)

        x = self.merge(
            x.contiguous().view(batch_dim, self.dim * self.num_heads, -1)
        )

        # residual + norm（稳定跨域训练）
        x = x + query
        x = self.norm(x.transpose(1, 2)).transpose(1, 2)
        x = self.dropout(x)

        return x


# ==============================
# AttentionalPropagation（接口保持原版）
# ==============================
class AttentionalPropagation(nn.Module):
    def __init__(self, feature_dim: int, num_heads: int):
        super().__init__()
        self.attn = MultiHeadedAttention(num_heads, feature_dim)

    def forward(self, x, source1, source2):
        return self.attn(x, source1, source2)


# ==============================
# 跨域小样本高光谱稳定对齐GNN（最终版）
# ==============================
class AttentionalGNN(nn.Module):

    def __init__(self, num_support, feature_dim: int, layer_names: list):
        super().__init__()

        self.layers = nn.ModuleList([
            AttentionalPropagation(feature_dim, 4)
            for _ in range(len(layer_names))
        ])

        self.names = layer_names

        self.mlp = MLP([feature_dim * 2, feature_dim * 2, feature_dim])
        self.mlp_dis = MLP([num_support, feature_dim, feature_dim])

        nn.init.constant_(self.mlp[-1].bias, 0.0)
        nn.init.constant_(self.mlp_dis[-1].bias, 0.0)

        self.mmd = MMD_loss()

        # 自适应结构权重（小样本稳定）
        self.alpha = nn.Parameter(torch.tensor(0.1))

    # 原型结构对齐（高光谱友好）
    def prototype_structure_alignment(self, f_s, f_t):
        proto_s = f_s.mean(dim=0, keepdim=True)
        proto_t = f_t.mean(dim=0, keepdim=True)

        Gs = torch.matmul(proto_s, proto_s.t())
        Gt = torch.matmul(proto_t, proto_t.t())

        Gs = F.normalize(Gs, dim=1)
        Gt = F.normalize(Gt, dim=1)

        return torch.mean((Gs - Gt) ** 2)

    def forward(self, p_nodes_src, p_nodes_tar,
                dis_nodes_src, dis_nodes_tar):

        flag = 0

        # ===== 可训练标准化（替代sklearn）=====
        for i in range(len(p_nodes_src)):
            # ===== point nodes =====
            p_nodes_src[i] = normalize_feature(
                p_nodes_src[i].squeeze(0)
            ).unsqueeze(0).transpose(2, 1)

            p_nodes_tar[i] = normalize_feature(
                p_nodes_tar[i].squeeze(0)
            ).unsqueeze(0).transpose(2, 1)

            # ===== distribution nodes（关键修复）=====
            dis_src = normalize_feature(dis_nodes_src[i].squeeze(0))
            dis_tar = normalize_feature(dis_nodes_tar[i].squeeze(0))

            dis_nodes_src[i] = self.mlp_dis(
                dis_src.unsqueeze(0).transpose(2, 1)
            )

            dis_nodes_tar[i] = self.mlp_dis(
                dis_tar.unsqueeze(0).transpose(2, 1)
            )

        # ===== 跨域传播 =====
        for layer, name in zip(self.layers, self.names):

            if name == 'cross':
                p_src0, p_src1 = p_nodes_tar[flag], p_nodes_src[flag]
                d_src0, d_src1 = dis_nodes_tar[flag], dis_nodes_src[flag]

            delta0 = layer(p_nodes_src[flag], p_src0, p_src0)
            delta1 = layer(p_nodes_tar[flag], p_src1, p_src1)

            p_nodes_src_temp = delta0 * p_src0
            p_nodes_tar_temp = delta1 * p_src1

            delta0 = layer(dis_nodes_src[flag], d_src0, p_nodes_src_temp)
            delta1 = layer(dis_nodes_tar[flag], d_src1, p_nodes_tar_temp)

            p_nodes_src[0] = p_nodes_src[0] + self.mlp(
                torch.cat([p_nodes_src[flag], delta0], dim=1)
            )

            p_nodes_tar[0] = p_nodes_tar[0] + self.mlp(
                torch.cat([p_nodes_tar[flag], delta1], dim=1)
            )

            flag += 1

        # ===== 损失计算（保持原版接口）=====
        f_s = p_nodes_src[0].squeeze(0).transpose(1, 0)
        f_t = p_nodes_tar[0].squeeze(0).transpose(1, 0)

        loss_mmd = self.mmd(f_s, f_t)
        loss_proto = self.prototype_structure_alignment(f_s, f_t)

        total_loss = loss_mmd + self.alpha * loss_proto

        return total_loss
