'''Yang, Ling, et al. 
"Dpgn: Distribution propagation graph network for few-shot learning." 
Proceedings of the IEEE/CVF conference on computer vision and pattern recognition. 2020.'''

import torch.nn as nn
import torch.nn.functional as F
import torch



import torch
import torch.nn as nn
import torch.nn.functional as F


class PointSimilarity(nn.Module):
    def __init__(self, in_c, base_c, dropout=0.0):
        super(PointSimilarity, self).__init__()
        self.in_c = in_c
        self.base_c = base_c
        self.dropout = dropout

        self.uncertainty_proj = nn.Sequential(
            nn.Linear(in_c, in_c),
            nn.Sigmoid()
        )

        layer_list = [
            nn.Conv2d(in_channels=self.in_c, out_channels=self.base_c * 2, kernel_size=1, bias=False),
            nn.BatchNorm2d(self.base_c * 2),
            nn.LeakyReLU()
        ]
        if self.dropout > 0:
            layer_list.append(nn.Dropout2d(self.dropout))

        layer_list += [
            nn.Conv2d(self.base_c * 2, self.base_c, kernel_size=1, bias=False),
            nn.BatchNorm2d(self.base_c),
            nn.LeakyReLU()
        ]

        if self.dropout > 0:
            layer_list.append(nn.Dropout2d(self.dropout))

        layer_list.append(nn.Conv2d(self.base_c, 1, kernel_size=1))
        self.point_sim_transform = nn.Sequential(*layer_list)

    def forward(self, vp_last_gen, ep_last_gen, distance_metric):
        B, N, C = vp_last_gen.size()

        self.uncertainty_proj.cuda()
        uncertainty = self.uncertainty_proj(vp_last_gen)

        vp_i = vp_last_gen.unsqueeze(2)
        vp_j = vp_last_gen.unsqueeze(1)

        if distance_metric == 'l2':
            vp_similarity = (vp_i - vp_j) ** 2
        else:
            vp_similarity = torch.abs(vp_i - vp_j)

        weight = (uncertainty.unsqueeze(2) + uncertainty.unsqueeze(1)) / 2
        vp_similarity = vp_similarity * weight

        trans_similarity = vp_similarity.permute(0, 3, 1, 2)
        ep_ij = torch.sigmoid(self.point_sim_transform(trans_similarity)).squeeze(1)

        # ===== device 行为对齐原版 =====
        diag_mask = 1.0 - torch.eye(N).unsqueeze(0).repeat(B, 1, 1).to(ep_last_gen.get_device())
        ep_last_gen = ep_last_gen * diag_mask
        norm = torch.sum(ep_last_gen, -1, keepdim=True)

        ep_ij = F.normalize(ep_ij * ep_last_gen, p=1, dim=-1) * norm

        diag_rev = torch.eye(N).unsqueeze(0).to(ep_last_gen.get_device())
        ep_ij = ep_ij + (diag_rev + 1e-6)
        ep_ij = ep_ij / torch.sum(ep_ij, dim=2, keepdim=True)

        node_similarity_l2 = -torch.sum(vp_similarity, dim=3)

        return ep_ij, node_similarity_l2


class P2DAgg(nn.Module):
    def __init__(self, in_c, out_c):
        super(P2DAgg, self).__init__()
        self.p2d_transform = nn.Sequential(
            nn.Linear(in_c, out_c),
            nn.LeakyReLU()
        )

    def forward(self, point_edge, distribution_node):
        B, N, _ = point_edge.size()
        distribution_node = torch.cat(
            [point_edge[:, :, :distribution_node.size(2)], distribution_node], dim=2
        )
        distribution_node = distribution_node.view(B * N, -1)

        # ===== 强制 GPU（与原版一致）=====
        self.p2d_transform = self.p2d_transform.to(distribution_node.device)


        distribution_node = self.p2d_transform(distribution_node)
        distribution_node = distribution_node.view(B, N, -1)
        return distribution_node


class DistributionSimilarity(nn.Module):
    def __init__(self, in_c, base_c, dropout=0.0):
        super(DistributionSimilarity, self).__init__()
        self.sim_net = nn.Sequential(
            nn.Conv2d(in_c, base_c * 2, 1, bias=False),
            nn.BatchNorm2d(base_c * 2),
            nn.LeakyReLU(),
            nn.Conv2d(base_c * 2, base_c, 1, bias=False),
            nn.BatchNorm2d(base_c),
            nn.LeakyReLU(),
            nn.Conv2d(base_c, 1, 1)
        )

    def forward(self, vd_curr_gen, ed_last_gen, distance_metric):
        B, N, C = vd_curr_gen.size()

        vd_i = vd_curr_gen.unsqueeze(2)
        vd_j = vd_curr_gen.unsqueeze(1)

        if distance_metric == 'l2':
            sim = (vd_i - vd_j) ** 2
        else:
            sim = torch.abs(vd_i - vd_j)

        sim = sim.permute(0, 3, 1, 2)
        ed_ij = torch.sigmoid(self.sim_net(sim)).squeeze(1)

        diag = 1.0 - torch.eye(N).unsqueeze(0).repeat(B, 1, 1).to(ed_last_gen.get_device())
        ed_ij = ed_ij * diag
        ed_ij = ed_ij / (torch.sum(ed_ij, dim=2, keepdim=True) + 1e-6)

        return ed_ij


class D2PAgg(nn.Module):
    def __init__(self, in_c, base_c, dropout=0.0):
        super(D2PAgg, self).__init__()
        self.transform = nn.Sequential(
            nn.Conv2d(in_c, base_c * 2, 1, bias=False),
            nn.BatchNorm2d(base_c * 2),
            nn.LeakyReLU(),
            nn.Conv2d(base_c * 2, base_c, 1, bias=False),
            nn.BatchNorm2d(base_c),
            nn.LeakyReLU()
        )

    def forward(self, distribution_edge, point_node):
        B, N, _ = point_node.size()

        diag = 1.0 - torch.eye(N).unsqueeze(0).repeat(B, 1, 1).to(distribution_edge.get_device())
        edge = F.normalize(distribution_edge * diag, p=1, dim=-1)

        aggr = torch.bmm(edge, point_node)
        node_feat = torch.cat([point_node, aggr], -1).transpose(1, 2)
        node_feat = self.transform(node_feat.unsqueeze(-1))
        return node_feat.squeeze(-1).transpose(1, 2)


class DPGN(nn.Module):
    def __init__(self, num_generations, dropout, num_support_sample,
                 num_sample, point_metric, distribution_metric, emb_size):
        super(DPGN, self).__init__()
        self.generation = num_generations
        self.point_metric = point_metric
        self.distribution_metric = distribution_metric

        self.initial_edge = PointSimilarity(emb_size, emb_size, dropout)

        for l in range(num_generations):
            self.add_module(f'point_sim_generation_{l}',
                            PointSimilarity(emb_size, emb_size, dropout))
            self.add_module(f'point2distribution_generation_{l}',
                            P2DAgg(2 * num_support_sample, num_support_sample))
            self.add_module(f'distribution_sim_generation_{l}',
                            DistributionSimilarity(num_support_sample, num_support_sample, dropout))
            self.add_module(f'distribution2point_generation_{l}',
                            D2PAgg(emb_size * 2, emb_size, dropout))

    def forward(self, middle_node, point_node,
                distribution_node, distribution_edge, point_edge):

        point_similarities, distribution_similarities = [], []
        node_similarities_l2, distribution_nodes, point_nodes = [], [], []

        point_edge, _ = self.initial_edge(middle_node, point_edge, self.point_metric)

        for l in range(self.generation):
            point_edge, node_sim = self._modules[f'point_sim_generation_{l}'](
                point_node, point_edge, self.point_metric)
            distribution_node = self._modules[f'point2distribution_generation_{l}'](
                point_edge, distribution_node)
            distribution_edge = self._modules[f'distribution_sim_generation_{l}'](
                distribution_node, distribution_edge, self.distribution_metric)
            point_node = self._modules[f'distribution2point_generation_{l}'](
                distribution_edge, point_node)

            point_similarities.append(point_edge)
            node_similarities_l2.append(node_sim)
            distribution_similarities.append(distribution_edge)
            distribution_nodes.append(distribution_node)
            point_nodes.append(point_node)

        return point_similarities, node_similarities_l2, distribution_similarities, point_nodes, distribution_nodes
